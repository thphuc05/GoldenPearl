package entity;

import java.sql.Time;

/**
 * Entity đại diện cho ca làm việc của nhà hàng.
 *
 * <p>Ví dụ: Ca sáng (06:00 – 14:00), Ca chiều (14:00 – 22:00), Ca tối (22:00 – 02:00).
 */
public class CaLam {

    private String maCa;
    private String tenCa;
    private Time gioBatDau;
    private Time gioKetThuc;
    private boolean trangThai; // true = đang hoạt động

    public CaLam() {}

    public CaLam(String maCa, String tenCa, Time gioBatDau, Time gioKetThuc, boolean trangThai) {
        this.maCa       = maCa;
        this.tenCa      = tenCa;
        this.gioBatDau  = gioBatDau;
        this.gioKetThuc = gioKetThuc;
        this.trangThai  = trangThai;
    }

    // ── Getters & Setters ───────────────────────────────────────────────────

    public String getMaCa() { return maCa; }
    public void setMaCa(String maCa) { this.maCa = maCa; }

    public String getTenCa() { return tenCa; }
    public void setTenCa(String tenCa) { this.tenCa = tenCa; }

    public Time getGioBatDau() { return gioBatDau; }
    public void setGioBatDau(Time gioBatDau) { this.gioBatDau = gioBatDau; }

    public Time getGioKetThuc() { return gioKetThuc; }
    public void setGioKetThuc(Time gioKetThuc) { this.gioKetThuc = gioKetThuc; }

    public boolean isTrangThai() { return trangThai; }
    public void setTrangThai(boolean trangThai) { this.trangThai = trangThai; }

    /**
     * Chuỗi hiển thị ngắn gọn: "Ca sáng (06:00 - 14:00)".
     */
    // ── Trạng thái realtime ──────────────────────────────────────────────────
    /** Các giá trị trạng thái hiển thị. */
    public static final String CHUA_MO  = "CHƯA MỞ";
    public static final String DANG_MO  = "ĐANG MỞ";
    public static final String DA_DONG  = "ĐÃ ĐÓNG";

    /**
     * Tính trạng thái ca dựa theo giờ hệ thống hiện tại – KHÔNG lưu vào DB.
     * Logic:
     *   now < gioBatDau  → CHƯA MỞ
     *   gioBatDau ≤ now < gioKetThuc → ĐANG MỞ
     *   now ≥ gioKetThuc → ĐÃ ĐÓNG
     * Hỗ trợ ca vắt qua nửa đêm (gioBatDau > gioKetThuc).
     */
    public String getTrangThaiRealtime() {
        if (gioBatDau == null || gioKetThuc == null) return CHUA_MO;
        java.util.Calendar now = java.util.Calendar.getInstance();
        int nowMin  = now.get(java.util.Calendar.HOUR_OF_DAY) * 60
                + now.get(java.util.Calendar.MINUTE);
        int startMin = gioBatDau.getHours()  * 60 + gioBatDau.getMinutes();
        int endMin   = gioKetThuc.getHours() * 60 + gioKetThuc.getMinutes();

        // Ca vắt qua nửa đêm (ví dụ 22:00 → 06:00)
        if (startMin > endMin) {
            if (nowMin >= startMin || nowMin < endMin) return DANG_MO;
            return nowMin < startMin ? CHUA_MO : DA_DONG;
        }
        // Ca thông thường
        if (nowMin < startMin)  return CHUA_MO;
        if (nowMin < endMin)    return DANG_MO;
        return DA_DONG;
    }

    public String getDisplayName() {
        String gbd = gioBatDau  != null ? gioBatDau.toString().substring(0, 5)  : "??:??";
        String gkt = gioKetThuc != null ? gioKetThuc.toString().substring(0, 5) : "??:??";
        return tenCa + " (" + gbd + " - " + gkt + ")";
    }

    @Override
    public String toString() {
        return getDisplayName();
    }
}
