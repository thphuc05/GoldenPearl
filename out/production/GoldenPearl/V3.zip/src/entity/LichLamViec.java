package entity;

import java.util.Date;

/**
 * Entity đại diện cho lịch làm việc: phân công một nhân viên vào một ca, một ngày cụ thể.
 *
 * <p>Quan hệ:
 * <ul>
 *   <li>Nhiều LichLamViec cho một NhanVien (1-N)</li>
 *   <li>Nhiều LichLamViec cho một CaLam (1-N)</li>
 *   <li>Unique constraint: (maNV, maCa, ngayLam) – mỗi nhân viên chỉ được 1 ca/ngày</li>
 * </ul>
 */
public class LichLamViec {

    private int    maLich;
    private NhanVien nhanVien;
    private CaLam    caLam;
    private Date     ngayLam;
    private String   ghiChu;

    public LichLamViec() {}

    public LichLamViec(int maLich, NhanVien nhanVien, CaLam caLam, Date ngayLam, String ghiChu) {
        this.maLich   = maLich;
        this.nhanVien = nhanVien;
        this.caLam    = caLam;
        this.ngayLam  = ngayLam;
        this.ghiChu   = ghiChu;
    }

    // ── Getters & Setters ───────────────────────────────────────────────────

    public int getMaLich() { return maLich; }
    public void setMaLich(int maLich) { this.maLich = maLich; }

    public NhanVien getNhanVien() { return nhanVien; }
    public void setNhanVien(NhanVien nhanVien) { this.nhanVien = nhanVien; }

    public CaLam getCaLam() { return caLam; }
    public void setCaLam(CaLam caLam) { this.caLam = caLam; }

    public Date getNgayLam() { return ngayLam; }
    public void setNgayLam(Date ngayLam) { this.ngayLam = ngayLam; }

    public String getGhiChu() { return ghiChu; }
    public void setGhiChu(String ghiChu) { this.ghiChu = ghiChu; }

    @Override
    public String toString() {
        return "LichLamViec [maLich=" + maLich
                + ", nv=" + (nhanVien != null ? nhanVien.getMaNV() : "null")
                + ", ca=" + (caLam    != null ? caLam.getTenCa()   : "null")
                + ", ngay=" + ngayLam + "]";
    }
}
