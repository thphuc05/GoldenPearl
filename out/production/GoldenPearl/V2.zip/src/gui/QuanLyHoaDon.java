package gui;

import dao.CaLam_DAO;
import dao.ChiTietHoaDon_DAO;
import dao.HoaDon_DAO;
import dao.KhuVuc_DAO;
import entity.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;

/**
 * Panel quản lý hóa đơn – phiên bản 2.0.
 *
 * <p>Tính năng mới so với v1:
 * <ul>
 *   <li>Hiển thị cột <b>Trạng Thái Thanh Toán</b> chi tiết (Chưa TT / Đã TT / Đã cọc…)</li>
 *   <li>Hiển thị cột <b>Hình Thức</b> thanh toán</li>
 *   <li>Hiển thị cột <b>Ca Làm</b></li>
 *   <li>Nút <b>THANH TOÁN</b> – chọn hình thức và cập nhật ngay DB + JTable</li>
 *   <li>Nút <b>CẬP NHẬT TT</b> – đổi trạng thái không kèm hình thức (cọc, hủy…)</li>
 *   <li>Lọc theo ca làm qua ComboBox mới</li>
 * </ul>
 */
public class QuanLyHoaDon extends JPanel {

    // ── Filter bar ──────────────────────────────────────────────────────────
    private JTextField   txtSearch;
    private JTextField   txtFromDate;
    private JTextField   txtToDate;
    private JComboBox<String> cmbKhuVuc;
    private JComboBox<String> cmbTrangThai;
    private JComboBox<String> cmbCaLam;   // [MỚI]
    private JButton      btnSearch;
    private JButton      btnRefresh;

    // ── Action buttons ──────────────────────────────────────────────────────
    private JButton btnPrint;
    private JButton btnViewDetail;
    private JButton btnThanhToan;       // [MỚI]
    private JButton btnCapNhatTrangThai; // [MỚI]

    // ── Tables ──────────────────────────────────────────────────────────────
    private JTable tableHoaDon;
    private JTable tableChiTiet;
    private DefaultTableModel modelHoaDon;
    private DefaultTableModel modelChiTiet;

    // ── Info labels ─────────────────────────────────────────────────────────
    private JLabel lblMaHD, lblNgayLap, lblNhanVien, lblKhachHang;
    private JLabel lblBan, lblTongTien, lblTienCoc, lblTongCong;
    private JLabel lblTrangThai;    // [CẬP NHẬT] hiển thị enum
    private JLabel lblHinhThuc;     // [MỚI]
    private JLabel lblCaLam;        // [MỚI]

    // ── DAOs ────────────────────────────────────────────────────────────────
    private final HoaDon_DAO      hdDao  = new HoaDon_DAO();
    private final ChiTietHoaDon_DAO ctDao = new ChiTietHoaDon_DAO();
    private final KhuVuc_DAO      kvDao  = new KhuVuc_DAO();
    private final CaLam_DAO       caDao  = new CaLam_DAO();

    // ── Cache ───────────────────────────────────────────────────────────────
    private Map<String, String> maHDToKhuVuc = new HashMap<>();
    private Map<String, String> maHDToBan    = new HashMap<>();
    private List<HoaDon>        cachedHoaDon = new ArrayList<>();
    private List<CaLam>         dsCaLam      = new ArrayList<>(); // [MỚI]

    // ── Colors ──────────────────────────────────────────────────────────────
    private static final Color TEXT_DARK    = Color.decode("#333333");
    private static final Color BORDER_COLOR = Color.decode("#E0E0E0");
    private static final Color SELECT_BG    = Color.decode("#EBF5FB");
    private static final Color GREEN_STATUS = Color.decode("#27AE60");
    private static final Color RED_STATUS   = Color.decode("#E74C3C");
    private static final Color MAIN_BLUE    = Color.decode("#0B3D59");
    private static final Color GOLD_COLOR   = Color.decode("#C5A059");
    private static final Color ORANGE_COLOR = Color.decode("#E67E22");
    private static final Color PURPLE_COLOR = Color.decode("#8E44AD");

    // ── Formatters ──────────────────────────────────────────────────────────
    private final SimpleDateFormat dateSdf     = new SimpleDateFormat("dd/MM/yyyy");
    private final SimpleDateFormat timeSdf     = new SimpleDateFormat("HH:mm");

    // ════════════════════════════════════════════════════════════════════════
    //  CONSTRUCTOR
    // ════════════════════════════════════════════════════════════════════════

    public QuanLyHoaDon() {
        setLayout(new BorderLayout(0, 10));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(14, 18, 14, 18));

        JLabel lblTitle = new JLabel("QUẢN LÝ HÓA ĐƠN", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Inter Bold", Font.BOLD, 30));
        lblTitle.setForeground(TEXT_DARK);
        add(lblTitle, BorderLayout.NORTH);

        JPanel content = new JPanel(new BorderLayout(0, 10));
        content.setBackground(Color.WHITE);
        add(content, BorderLayout.CENTER);

        content.add(createFilterPanel(), BorderLayout.NORTH);
        content.add(createCenterPanel(), BorderLayout.CENTER);
        content.add(createBottomPanel(), BorderLayout.SOUTH);

        txtFromDate.setText(dateSdf.format(new Date()));
        txtToDate.setText(dateSdf.format(new Date()));

        bindEvents();
        loadComboDataAsync();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  UI BUILDING
    // ════════════════════════════════════════════════════════════════════════

    private JPanel createFilterPanel() {
        JPanel pFilter = new JPanel(new GridBagLayout());
        pFilter.setBackground(Color.WHITE);
        TitledBorder border = BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(BORDER_COLOR), "BỘ LỌC TÌM KIẾM");
        border.setTitleFont(new Font("Inter Bold", Font.BOLD, 13));
        border.setTitleColor(TEXT_DARK);
        pFilter.setBorder(border);

        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(8, 6, 8, 6);
        g.fill   = GridBagConstraints.HORIZONTAL;

        // Row 0
        g.gridy = 0;
        addFilter(pFilter, g, 0, "Mã HĐ:", txtSearch = mkField(110));
        addFilter(pFilter, g, 2, "Khu vực:", cmbKhuVuc = mkCombo(130));
        addFilter(pFilter, g, 4, "Trạng thái:", cmbTrangThai = mkCombo(150));
        // Trạng thái options
        for (TrangThaiThanhToan t : TrangThaiThanhToan.values())
            cmbTrangThai.addItem(t.getDisplay());
        cmbTrangThai.insertItemAt("Tất cả", 0);
        cmbTrangThai.setSelectedIndex(0);

        addFilter(pFilter, g, 6, "Ca làm:", cmbCaLam = mkCombo(140));    // [MỚI]
        cmbCaLam.addItem("Tất cả ca");

        addFilter(pFilter, g, 8, "Từ ngày:", wrapDate(txtFromDate = mkReadonlyDate()));
        addFilter(pFilter, g, 10, "Đến ngày:", wrapDate(txtToDate = mkReadonlyDate()));

        g.gridx = 12; g.weightx = 0;
        btnSearch = mkBtn("TÌM KIẾM", MAIN_BLUE, Color.WHITE, 120);
        pFilter.add(btnSearch, g);

        return pFilter;
    }

    private void addFilter(JPanel p, GridBagConstraints g, int col, String labelText, Object comp) {
        g.gridx = col; g.weightx = 0;
        p.add(mkLabel(labelText), g);
        g.gridx = col + 1; g.weightx = 0.12;
        p.add(comp instanceof JPanel ? (JPanel) comp : (Component) comp, g);
    }

    private JPanel createCenterPanel() {
        JPanel center = new JPanel(new GridLayout(1, 2, 14, 0));
        center.setBackground(Color.WHITE);
        center.add(createInvoiceListPanel());
        center.add(createInvoiceDetailPanel());
        return center;
    }

    private JPanel createInvoiceListPanel() {
        JPanel left = new JPanel(new BorderLayout());
        left.setBackground(Color.WHITE);
        TitledBorder lb = BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(BORDER_COLOR), "DANH SÁCH HÓA ĐƠN");
        lb.setTitleFont(new Font("Inter Bold", Font.BOLD, 13));
        lb.setTitleColor(TEXT_DARK);
        left.setBorder(lb);

        // [CẬP NHẬT] thêm cột Hình Thức + Ca Làm
        String[] cols = {"Mã HĐ", "Ngày Lập", "Khách Hàng", "Bàn", "Trạng Thái", "Hình Thức", "Ca Làm"};
        modelHoaDon = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        tableHoaDon = new JTable(modelHoaDon);
        styleTable(tableHoaDon);
        tableHoaDon.getColumnModel().getColumn(0).setPreferredWidth(70);
        tableHoaDon.getColumnModel().getColumn(1).setPreferredWidth(120);
        tableHoaDon.getColumnModel().getColumn(2).setPreferredWidth(110);
        tableHoaDon.getColumnModel().getColumn(3).setPreferredWidth(90);
        tableHoaDon.getColumnModel().getColumn(4).setPreferredWidth(120);
        tableHoaDon.getColumnModel().getColumn(5).setPreferredWidth(100);
        tableHoaDon.getColumnModel().getColumn(6).setPreferredWidth(100);
        tableHoaDon.getColumnModel().getColumn(4).setCellRenderer(new StatusCellRenderer());

        left.add(new JScrollPane(tableHoaDon), BorderLayout.CENTER);
        return left;
    }

    private JPanel createInvoiceDetailPanel() {
        JPanel right = new JPanel(new BorderLayout(0, 8));
        right.setBackground(Color.WHITE);
        TitledBorder rb = BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(BORDER_COLOR), "CHI TIẾT HÓA ĐƠN");
        rb.setTitleFont(new Font("Inter Bold", Font.BOLD, 13));
        rb.setTitleColor(TEXT_DARK);
        right.setBorder(rb);
        right.add(createInfoPanel(), BorderLayout.NORTH);

        String[] colsCT = {"STT", "Tên Món Ăn", "SL", "Đơn Giá", "Thành Tiền"};
        modelChiTiet = new DefaultTableModel(colsCT, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tableChiTiet = new JTable(modelChiTiet);
        styleDetailTable(tableChiTiet);

        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        tableChiTiet.getColumnModel().getColumn(0).setCellRenderer(center);
        tableChiTiet.getColumnModel().getColumn(0).setPreferredWidth(38);
        tableChiTiet.getColumnModel().getColumn(2).setCellRenderer(center);
        tableChiTiet.getColumnModel().getColumn(2).setPreferredWidth(38);

        right.add(new JScrollPane(tableChiTiet), BorderLayout.CENTER);
        return right;
    }

    private JPanel createInfoPanel() {
        // [MỚI] 11 dòng thay vì 8
        JPanel info = new JPanel(new GridLayout(11, 1, 0, 3));
        info.setBackground(Color.WHITE);
        info.setBorder(new EmptyBorder(8, 10, 4, 10));

        lblMaHD      = mkInfoLabel();
        lblNgayLap   = mkInfoLabel();
        lblNhanVien  = mkInfoLabel();
        lblKhachHang = mkInfoLabel();
        lblBan       = mkInfoLabel();
        lblCaLam     = mkInfoLabel();   // [MỚI]
        lblTrangThai = mkInfoLabel();   // [CẬP NHẬT]
        lblHinhThuc  = mkInfoLabel();   // [MỚI]
        lblTongTien  = mkInfoLabel();
        lblTienCoc   = mkInfoLabel();
        lblTongCong  = mkInfoLabel();

        info.add(lblMaHD);
        info.add(lblNgayLap);
        info.add(lblNhanVien);
        info.add(lblKhachHang);
        info.add(lblBan);
        info.add(lblCaLam);
        info.add(lblTrangThai);
        info.add(lblHinhThuc);
        info.add(lblTongTien);
        info.add(lblTienCoc);
        info.add(lblTongCong);

        setInvoiceDetail(null, null);
        return info;
    }

    private JPanel createBottomPanel() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 4));
        p.setBackground(Color.WHITE);

        btnRefresh    = mkBtn("LÀM MỚI", Color.WHITE, TEXT_DARK, 160);
        btnRefresh.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));

        btnCapNhatTrangThai = mkBtn("CẬP NHẬT TT",  ORANGE_COLOR, Color.WHITE, 160); // [MỚI]
        btnThanhToan        = mkBtn("THANH TOÁN",   GREEN_STATUS, Color.WHITE, 160); // [MỚI]
        btnViewDetail       = mkBtn("XEM CHI TIẾT", GOLD_COLOR,   MAIN_BLUE,  160);
        btnPrint            = mkBtn("IN HÓA ĐƠN",  MAIN_BLUE,    Color.WHITE, 160);

        p.add(btnRefresh);
        p.add(btnCapNhatTrangThai);
        p.add(btnThanhToan);
        p.add(btnViewDetail);
        p.add(btnPrint);
        return p;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  EVENT BINDING
    // ════════════════════════════════════════════════════════════════════════

    private void bindEvents() {
        btnRefresh.addActionListener(e -> resetFiltersAndReload());
        btnSearch.addActionListener(e -> searchHoaDon());
        cmbKhuVuc.addActionListener(e -> applyCurrentFilters());
        cmbTrangThai.addActionListener(e -> applyCurrentFilters());
        cmbCaLam.addActionListener(e -> applyCurrentFilters());   // [MỚI]

        tableHoaDon.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                loadSelectedDetail();
                updateButtonState();
            }
        });

        btnViewDetail.addActionListener(e -> handleViewDetail());
        btnPrint.addActionListener(e -> handlePrint());
        btnThanhToan.addActionListener(e -> handleThanhToan());               // [MỚI]
        btnCapNhatTrangThai.addActionListener(e -> handleCapNhatTrangThai()); // [MỚI]
    }

    // ════════════════════════════════════════════════════════════════════════
    //  PUBLIC API
    // ════════════════════════════════════════════════════════════════════════

    public void refreshData() { loadDataFromDB(); }

    // ════════════════════════════════════════════════════════════════════════
    //  DATA LOADING
    // ════════════════════════════════════════════════════════════════════════

    private void loadComboDataAsync() {
        cmbKhuVuc.addItem("Tất cả");
        new SwingWorker<Object[], Void>() {
            @Override protected Object[] doInBackground() {
                return new Object[]{ kvDao.getAllKhuVuc(), caDao.getActiveCaLam() };
            }
            @Override protected void done() {
                try {
                    Object[] r = get();
                    List<KhuVuc> dsKV = (List<KhuVuc>) r[0];
                    dsCaLam = (List<CaLam>) r[1];
                    for (KhuVuc kv : dsKV) cmbKhuVuc.addItem(kv.getTenKV());
                    for (CaLam ca : dsCaLam) cmbCaLam.addItem(ca.getDisplayName());
                    loadDataFromDB();
                } catch (Exception e) { e.printStackTrace(); }
            }
        }.execute();
    }

    private void loadDataFromDB() {
        modelHoaDon.setRowCount(0);
        modelChiTiet.setRowCount(0);
        new SwingWorker<Object[], Void>() {
            @Override protected Object[] doInBackground() {
                return new Object[]{
                    hdDao.getKhuVucMapForAllHoaDon(),
                    hdDao.getDsBanDisplayForAllHoaDon(),
                    hdDao.getAllHoaDon()
                };
            }
            @Override @SuppressWarnings("unchecked") protected void done() {
                try {
                    Object[] r = get();
                    maHDToKhuVuc = (Map<String, String>) r[0];
                    maHDToBan    = (Map<String, String>) r[1];
                    List<HoaDon> ds = (List<HoaDon>) r[2];
                    cachedHoaDon = ds != null ? ds : new ArrayList<>();
                    applyCurrentFilters();
                } catch (Exception e) { e.printStackTrace(); }
            }
        }.execute();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  FILTER / SEARCH
    // ════════════════════════════════════════════════════════════════════════

    private void applyCurrentFilters() {
        String selKV = (String) cmbKhuVuc.getSelectedItem();
        String selTT = (String) cmbTrangThai.getSelectedItem();
        String selCa = (String) cmbCaLam.getSelectedItem();

        boolean filterKV = selKV != null && !selKV.equals("Tất cả");
        TrangThaiThanhToan filterTT = resolveTrangThaiFilter(selTT);
        CaLam filterCa = resolveCaFilter(selCa);

        modelHoaDon.setRowCount(0);

        for (HoaDon hd : cachedHoaDon) {
            if (filterKV) {
                String kv = maHDToKhuVuc.get(hd.getMaHD());
                if (!selKV.equals(kv)) continue;
            }
            if (filterTT != null && hd.getTrangThaiThanhToan() != filterTT) continue;
            if (filterCa != null) {
                if (hd.getCaLam() == null || !filterCa.getMaCa().equals(hd.getCaLam().getMaCa()))
                    continue;
            }
            addRowToInvoiceTable(hd);
        }

        if (modelHoaDon.getRowCount() > 0) {
            tableHoaDon.setRowSelectionInterval(0, 0);
            loadSelectedDetail();
        } else {
            setInvoiceDetail(null, null);
        }
        updateButtonState();
    }

    private TrangThaiThanhToan resolveTrangThaiFilter(String sel) {
        if (sel == null || sel.equals("Tất cả")) return null;
        return TrangThaiThanhToan.fromDisplay(sel);
    }

    private CaLam resolveCaFilter(String sel) {
        if (sel == null || sel.equals("Tất cả ca")) return null;
        for (CaLam ca : dsCaLam) if (ca.getDisplayName().equals(sel)) return ca;
        return null;
    }

    private void searchHoaDon() {
        String keyword = txtSearch.getText().trim();
        try {
            Date fromDate = dateSdf.parse(txtFromDate.getText());
            Date toDate   = dateSdf.parse(txtToDate.getText());
            Calendar cFrom = toStartOfDay(fromDate);
            Calendar cTo   = toEndOfDay(toDate);

            List<HoaDon> result = new ArrayList<>();
            if (!keyword.isEmpty()) {
                HoaDon hd = hdDao.getHoaDonByMa(keyword);
                if (hd != null && isInDateRange(hd.getNgayLap(), cFrom.getTime(), cTo.getTime()))
                    result.add(hd);
                else
                    JOptionPane.showMessageDialog(this, "Không tìm thấy hóa đơn phù hợp!");
            } else {
                List<HoaDon> ds = hdDao.getHoaDonByDateRange(cFrom.getTime(), cTo.getTime());
                if (ds != null) result.addAll(ds);
            }
            cachedHoaDon = result;
            applyCurrentFilters();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Lỗi định dạng ngày!");
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  DETAIL
    // ════════════════════════════════════════════════════════════════════════

    private void loadSelectedDetail() {
        int row = tableHoaDon.getSelectedRow();
        if (row == -1) { setInvoiceDetail(null, null); return; }
        final String maHD = modelHoaDon.getValueAt(row, 0).toString();

        new SwingWorker<Object[], Void>() {
            @Override protected Object[] doInBackground() {
                return new Object[]{ hdDao.getHoaDonByMa(maHD), ctDao.getChiTietByMaHD(maHD) };
            }
            @Override @SuppressWarnings("unchecked") protected void done() {
                try {
                    Object[] r = get();
                    setInvoiceDetail((HoaDon) r[0], (List<ChiTietHoaDon>) r[1]);
                } catch (Exception e) { e.printStackTrace(); }
            }
        }.execute();
    }

    private void setInvoiceDetail(HoaDon hd, List<ChiTietHoaDon> dsCT) {
        if (modelChiTiet != null) modelChiTiet.setRowCount(0);

        if (hd == null) {
            lblMaHD.setText("Mã HĐ: ");
            lblNgayLap.setText("Ngày Lập: ");
            lblNhanVien.setText("Nhân Viên: ");
            lblKhachHang.setText("Khách Hàng: ");
            lblBan.setText("Bàn: ");
            lblCaLam.setText("Ca Làm: ");
            lblTrangThai.setText("Trạng Thái: ");
            lblHinhThuc.setText("Hình Thức TT: ");
            lblTongTien.setText("Tổng Tiền: ");
            lblTienCoc.setText("Tiền Cọc: ");
            lblTongCong.setText("Tổng Cộng: ");
            return;
        }

        lblMaHD.setText("Mã HĐ: " + hd.getMaHD());

        String ngay = hd.getNgayLap() != null ? dateSdf.format(hd.getNgayLap()) : "";
        String gio  = hd.getThoiGian() != null
                ? hd.getThoiGian().toString().substring(0, 5)
                : (hd.getNgayLap() != null ? timeSdf.format(hd.getNgayLap()) : "");
        lblNgayLap.setText("Ngày Lập: " + ngay + "  " + gio);

        lblNhanVien.setText("Nhân Viên: " + (hd.getNhanVien() != null
                ? hd.getNhanVien().getMaNV() + " - " + nvTen(hd.getNhanVien()) : ""));

        lblKhachHang.setText("Khách Hàng: " + (hd.getKhachHang() != null
                ? hd.getKhachHang().getMaKH() + khTen(hd.getKhachHang()) : "Khách vãng lai"));

        lblBan.setText("Bàn: " + (hd.getDonDatBan() != null
                ? maHDToBan.getOrDefault(hd.getMaHD(), "") : ""));

        // [MỚI] Ca làm
        if (hd.getCaLam() != null) {
            lblCaLam.setText("Ca Làm: " + hd.getCaLam().getDisplayName());
            lblCaLam.setForeground(MAIN_BLUE);
        } else {
            lblCaLam.setText("Ca Làm: (chưa gán)");
            lblCaLam.setForeground(Color.GRAY);
        }

        // [MỚI] Trạng thái thanh toán
        TrangThaiThanhToan tt = hd.getTrangThaiThanhToan();
        lblTrangThai.setText("Trạng Thái: " + tt.getDisplay());
        switch (tt) {
            case DA_THANH_TOAN:  lblTrangThai.setForeground(GREEN_STATUS);  break;
            case CHUA_THANH_TOAN: lblTrangThai.setForeground(ORANGE_COLOR); break;
            case DA_COC:         lblTrangThai.setForeground(PURPLE_COLOR);  break;
            case DA_HUY:         lblTrangThai.setForeground(RED_STATUS);    break;
            default:             lblTrangThai.setForeground(TEXT_DARK);
        }

        // [MỚI] Hình thức thanh toán
        HinhThucThanhToan ht = hd.getHinhThucThanhToan();
        lblHinhThuc.setText("Hình Thức TT: " + (ht != null ? ht.getDisplay() : "(chưa có)"));
        lblHinhThuc.setForeground(ht != null ? MAIN_BLUE : Color.GRAY);

        // Chi tiết món
        double tongTienMon = 0;
        if (dsCT != null) {
            for (ChiTietHoaDon ct : dsCT) {
                tongTienMon += ct.getThanhTien();
                modelChiTiet.addRow(new Object[]{
                    modelChiTiet.getRowCount() + 1,
                    ct.getMonAn() != null ? ct.getMonAn().getTenMon() : "",
                    ct.getSoLuong(),
                    String.format("%,.0fđ", ct.getDonGia()),
                    String.format("%,.0fđ", ct.getThanhTien())
                });
            }
        }

        double tienCoc = hd.getTienCoc();
        double hieuSo  = tongTienMon - tienCoc;
        lblTongTien.setText("Tổng tiền món: " + String.format("%,.0fđ", tongTienMon));
        lblTienCoc.setText("Tiền đã cọc: "    + String.format("%,.0fđ", tienCoc));

        if (hieuSo < 0) {
            lblTongCong.setText("TIỀN HOÀN LẠI: " + String.format("%,.0fđ", Math.abs(hieuSo)));
            lblTongCong.setForeground(new Color(46, 204, 113));
        } else {
            lblTongCong.setText("CẦN THANH TOÁN: " + String.format("%,.0fđ", hieuSo));
            lblTongCong.setForeground(RED_STATUS);
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  ACTION HANDLERS
    // ════════════════════════════════════════════════════════════════════════

    /** [MỚI] Thanh toán hóa đơn: chọn hình thức → cập nhật DB + UI. */
    private void handleThanhToan() {
        int row = tableHoaDon.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Chọn hóa đơn cần thanh toán!"); return; }
        String maHD = modelHoaDon.getValueAt(row, 0).toString();

        // Kiểm tra trạng thái hiện tại
        HoaDon hd = hdDao.getHoaDonByMa(maHD);
        if (hd == null) return;
        if (hd.getTrangThaiThanhToan() == TrangThaiThanhToan.DA_THANH_TOAN) {
            JOptionPane.showMessageDialog(this, "Hóa đơn này đã thanh toán!");
            return;
        }

        // Dialog chọn hình thức
        HinhThucThanhToan[] options = HinhThucThanhToan.values();
        String[] labels = new String[options.length];
        for (int i = 0; i < options.length; i++) labels[i] = options[i].getDisplay();

        int choice = JOptionPane.showOptionDialog(this,
                "Chọn hình thức thanh toán cho hóa đơn " + maHD + ":",
                "Thanh Toán",
                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE,
                null, labels, labels[0]);

        if (choice < 0) return; // người dùng đóng dialog

        HinhThucThanhToan hinhThuc = options[choice];
        boolean ok = hdDao.updateThanhToan(maHD, TrangThaiThanhToan.DA_THANH_TOAN, hinhThuc);
        if (ok) {
            JOptionPane.showMessageDialog(this,
                    "Thanh toán thành công!\nHình thức: " + hinhThuc.getDisplay(),
                    "Thành công", JOptionPane.INFORMATION_MESSAGE);
            loadDataFromDB();
        } else {
            JOptionPane.showMessageDialog(this, "Lỗi cập nhật database!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    /** [MỚI] Cập nhật trạng thái không kèm thanh toán (cọc, hủy…). */
    private void handleCapNhatTrangThai() {
        int row = tableHoaDon.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Chọn hóa đơn cần cập nhật!"); return; }
        String maHD = modelHoaDon.getValueAt(row, 0).toString();

        TrangThaiThanhToan[] options = TrangThaiThanhToan.values();
        String[] labels = new String[options.length];
        for (int i = 0; i < options.length; i++) labels[i] = options[i].getDisplay();

        int choice = JOptionPane.showOptionDialog(this,
                "Chọn trạng thái mới cho hóa đơn " + maHD + ":",
                "Cập Nhật Trạng Thái",
                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE,
                null, labels, labels[0]);

        if (choice < 0) return;

        boolean ok = hdDao.updateTrangThai(maHD, options[choice]);
        if (ok) {
            JOptionPane.showMessageDialog(this, "Đã cập nhật trạng thái: " + options[choice].getDisplay());
            loadDataFromDB();
        } else {
            JOptionPane.showMessageDialog(this, "Lỗi cập nhật!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleViewDetail() {
        int row = tableHoaDon.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Chọn hóa đơn cần xem!"); return; }
        String maHD = modelHoaDon.getValueAt(row, 0).toString();
        HoaDon hd = hdDao.getHoaDonByMa(maHD);
        if (hd != null) {
            List<ChiTietHoaDon> dsCT = ctDao.getChiTietByMaHD(maHD);
            String tenBan = maHDToBan.getOrDefault(maHD, "");
            new QuanLyHoaDon_CTHD(SwingUtilities.getWindowAncestor(this), hd, dsCT, true, tenBan)
                    .setVisible(true);
        }
    }

    private void handlePrint() {
        int row = tableHoaDon.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Chọn hóa đơn cần in!"); return; }
        String maHD = modelHoaDon.getValueAt(row, 0).toString();
        Object[] opts = {"Xác nhận", "Hủy"};
        int choice = JOptionPane.showOptionDialog(this,
                "Bạn chắc chắn muốn in hóa đơn " + maHD + "?",
                "Xác nhận in hóa đơn",
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE,
                null, opts, opts[0]);
        if (choice == 0)
            JOptionPane.showMessageDialog(this, "In hóa đơn thành công!", "Thông báo",
                    JOptionPane.INFORMATION_MESSAGE);
    }

    private void resetFiltersAndReload() {
        txtSearch.setText("");
        cmbKhuVuc.setSelectedIndex(0);
        cmbTrangThai.setSelectedIndex(0);
        cmbCaLam.setSelectedIndex(0);
        txtFromDate.setText(dateSdf.format(new Date()));
        txtToDate.setText(dateSdf.format(new Date()));
        loadDataFromDB();
    }

    /** Ẩn/hiện nút Thanh Toán theo trạng thái hóa đơn đang chọn. */
    private void updateButtonState() {
        int row = tableHoaDon.getSelectedRow();
        if (row == -1) {
            btnThanhToan.setEnabled(false);
            btnCapNhatTrangThai.setEnabled(false);
            return;
        }
        btnCapNhatTrangThai.setEnabled(true);
        // Chỉ cho thanh toán khi chưa DA_THANH_TOAN
        String ttText = modelHoaDon.getValueAt(row, 4).toString();
        btnThanhToan.setEnabled(!TrangThaiThanhToan.DA_THANH_TOAN.getDisplay().equals(ttText));
    }

    // ════════════════════════════════════════════════════════════════════════
    //  TABLE ROW HELPERS
    // ════════════════════════════════════════════════════════════════════════

    private void addRowToInvoiceTable(HoaDon hd) {
        String ngayGio = "";
        if (hd.getNgayLap() != null) {
            String ngay = dateSdf.format(hd.getNgayLap());
            String gio  = hd.getThoiGian() != null
                    ? hd.getThoiGian().toString().substring(0, 5)
                    : timeSdf.format(hd.getNgayLap());
            ngayGio = ngay + " " + gio;
        }
        String tenBan = maHDToBan.getOrDefault(hd.getMaHD(), "");
        String ht  = hd.getHinhThucThanhToan() != null ? hd.getHinhThucThanhToan().getDisplay() : "";
        String ca  = hd.getCaLam() != null ? hd.getCaLam().getTenCa() : "";

        modelHoaDon.addRow(new Object[]{
            hd.getMaHD(),
            ngayGio,
            hd.getKhachHang() != null
                    ? hd.getKhachHang().getMaKH() + khTen(hd.getKhachHang())
                    : "Khách vãng lai",
            tenBan,
            hd.getTrangThaiThanhToan().getDisplay(),   // [CẬP NHẬT]
            ht,                                         // [MỚI]
            ca                                          // [MỚI]
        });
    }

    // ════════════════════════════════════════════════════════════════════════
    //  DATE HELPERS
    // ════════════════════════════════════════════════════════════════════════

    private Calendar toStartOfDay(Date d) {
        Calendar c = Calendar.getInstance(); c.setTime(d);
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);      c.set(Calendar.MILLISECOND, 0);
        return c;
    }
    private Calendar toEndOfDay(Date d) {
        Calendar c = Calendar.getInstance(); c.setTime(d);
        c.set(Calendar.HOUR_OF_DAY, 23); c.set(Calendar.MINUTE, 59);
        c.set(Calendar.SECOND, 59);       c.set(Calendar.MILLISECOND, 999);
        return c;
    }
    private boolean isInDateRange(Date date, Date from, Date to) {
        return date != null && !date.before(from) && !date.after(to);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  STRING HELPERS
    // ════════════════════════════════════════════════════════════════════════

    private String nvTen(NhanVien nv) {
        return (nv.getTenNV() != null && !nv.getTenNV().isEmpty()) ? " - " + nv.getTenNV() : "";
    }
    private String khTen(KhachHang kh) {
        return (kh.getTenKH() != null && !kh.getTenKH().isEmpty()) ? " – " + kh.getTenKH() : "";
    }

    // ════════════════════════════════════════════════════════════════════════
    //  UI FACTORY HELPERS
    // ════════════════════════════════════════════════════════════════════════

    private JLabel mkLabel(String t) {
        JLabel l = new JLabel(t);
        l.setFont(new Font("Inter Bold", Font.BOLD, 13));
        l.setForeground(TEXT_DARK);
        return l;
    }
    private JTextField mkField(int w) {
        JTextField f = new JTextField();
        f.setFont(new Font("Inter", Font.PLAIN, 13));
        f.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));
        f.setPreferredSize(new Dimension(w, 40));
        return f;
    }
    private JComboBox<String> mkCombo(int w) {
        JComboBox<String> c = new JComboBox<>();
        c.setFont(new Font("Inter", Font.PLAIN, 13));
        c.setPreferredSize(new Dimension(w, 40));
        c.setBackground(Color.WHITE);
        return c;
    }
    private JTextField mkReadonlyDate() {
        JTextField f = mkField(100);
        f.setEditable(false);
        f.setHorizontalAlignment(SwingConstants.CENTER);
        return f;
    }
    private JPanel wrapDate(JTextField field) {
        JButton btn = new JButton("📅");
        btn.setPreferredSize(new Dimension(40, 40));
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));
        btn.setBackground(Color.WHITE);
        btn.addActionListener(e -> new DatePickerDialog(
                (JFrame) SwingUtilities.getWindowAncestor(this), field).setVisible(true));
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(Color.WHITE);
        p.add(field, BorderLayout.CENTER);
        p.add(btn, BorderLayout.EAST);
        return p;
    }
    private JButton mkBtn(String t, Color bg, Color fg, int w) {
        JButton b = new JButton(t);
        b.setFont(new Font("Inter Bold", Font.BOLD, 13));
        b.setBackground(bg); b.setForeground(fg);
        b.setFocusPainted(false);
        b.setPreferredSize(new Dimension(w, 44));
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return b;
    }
    private JLabel mkInfoLabel() {
        JLabel l = new JLabel();
        l.setFont(new Font("Inter Bold", Font.BOLD, 13));
        l.setForeground(TEXT_DARK);
        return l;
    }
    private void styleTable(JTable t) {
        t.setFont(new Font("Inter", Font.PLAIN, 13));
        t.setRowHeight(36);
        t.setSelectionBackground(SELECT_BG);
        t.setSelectionForeground(TEXT_DARK);
        t.getTableHeader().setFont(new Font("Inter Bold", Font.BOLD, 13));
        t.getTableHeader().setPreferredSize(new Dimension(0, 38));
        t.setGridColor(new Color(235, 235, 235));
        t.setBackground(Color.WHITE);
        t.setShowVerticalLines(false);
        t.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
    }
    private void styleDetailTable(JTable t) {
        t.setFont(new Font("Inter", Font.PLAIN, 13));
        t.setRowHeight(32);
        t.getTableHeader().setFont(new Font("Inter Bold", Font.BOLD, 13));
        t.getTableHeader().setPreferredSize(new Dimension(0, 36));
        t.setGridColor(new Color(235, 235, 235));
        t.setBackground(Color.WHITE);
        t.setShowVerticalLines(false);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  INNER CLASSES
    // ════════════════════════════════════════════════════════════════════════

    /** Renderer tô màu cột Trạng Thái theo giá trị TrangThaiThanhToan. */
    private class StatusCellRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            if (!isSelected) {
                String s = value == null ? "" : value.toString();
                TrangThaiThanhToan tt = TrangThaiThanhToan.fromDisplay(s);
                switch (tt) {
                    case DA_THANH_TOAN:   setForeground(GREEN_STATUS);  break;
                    case CHUA_THANH_TOAN: setForeground(ORANGE_COLOR);  break;
                    case DA_COC:          setForeground(PURPLE_COLOR);  break;
                    case DA_HUY:          setForeground(RED_STATUS);    break;
                    default:              setForeground(TEXT_DARK);
                }
            } else {
                setForeground(TEXT_DARK);
            }
            setFont(new Font("Inter Bold", Font.BOLD, 13));
            return this;
        }
    }

    /** DatePicker giữ nguyên từ v1. */
    class DatePickerDialog extends JDialog {
        private final JTextField target;
        private final Calendar   cal;
        private JPanel daysPanel;
        private JLabel monthLabel;

        public DatePickerDialog(JFrame parent, JTextField target) {
            super(parent, "Chọn ngày", true);
            this.target = target;
            cal = Calendar.getInstance();
            try { if (!target.getText().isEmpty()) cal.setTime(dateSdf.parse(target.getText())); }
            catch (Exception ignored) {}
            setSize(300, 330);
            setLocationRelativeTo(target);
            setLayout(new BorderLayout());
            getContentPane().setBackground(Color.WHITE);
            add(createPickerHeader(), BorderLayout.NORTH);
            daysPanel = new JPanel(new GridLayout(0, 7, 2, 2));
            daysPanel.setBackground(Color.WHITE);
            daysPanel.setBorder(new EmptyBorder(6, 6, 6, 6));
            add(daysPanel, BorderLayout.CENTER);
            refreshCalendar();
        }
        private JPanel createPickerHeader() {
            JPanel h = new JPanel(new BorderLayout());
            h.setBackground(Color.WHITE); h.setBorder(new EmptyBorder(4,4,4,4));
            JButton prev = navBtn("<"); JButton next = navBtn(">");
            monthLabel = new JLabel("", SwingConstants.CENTER);
            monthLabel.setFont(new Font("Inter Bold", Font.BOLD, 14));
            prev.addActionListener(e -> { cal.add(Calendar.MONTH, -1); refreshCalendar(); });
            next.addActionListener(e -> { cal.add(Calendar.MONTH,  1); refreshCalendar(); });
            h.add(prev, BorderLayout.WEST); h.add(monthLabel, BorderLayout.CENTER); h.add(next, BorderLayout.EAST);
            return h;
        }
        private JButton navBtn(String t) {
            JButton b = new JButton(t); b.setFocusPainted(false);
            b.setBackground(Color.WHITE); b.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));
            return b;
        }
        private void refreshCalendar() {
            daysPanel.removeAll();
            monthLabel.setText(new SimpleDateFormat("MMMM yyyy").format(cal.getTime()));
            for (String d : new String[]{"CN","T2","T3","T4","T5","T6","T7"}) {
                JLabel l = new JLabel(d, SwingConstants.CENTER);
                l.setFont(new Font("Inter Bold", Font.BOLD, 11)); daysPanel.add(l);
            }
            Calendar tmp = (Calendar) cal.clone();
            tmp.set(Calendar.DAY_OF_MONTH, 1);
            int off = tmp.get(Calendar.DAY_OF_WEEK) - 1;
            int max = tmp.getActualMaximum(Calendar.DAY_OF_MONTH);
            for (int i = 0; i < off; i++) daysPanel.add(new JLabel(""));
            for (int day = 1; day <= max; day++) {
                final int d = day;
                JButton b = new JButton(String.valueOf(d));
                b.setFont(new Font("Inter", Font.PLAIN, 12)); b.setFocusPainted(false);
                b.setBackground(Color.WHITE); b.setBorder(BorderFactory.createLineBorder(new Color(220,220,220)));
                b.addActionListener(e -> { cal.set(Calendar.DAY_OF_MONTH, d); target.setText(dateSdf.format(cal.getTime())); dispose(); });
                daysPanel.add(b);
            }
            daysPanel.revalidate(); daysPanel.repaint();
        }
    }
}
