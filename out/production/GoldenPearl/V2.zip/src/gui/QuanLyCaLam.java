package gui;

import dao.*;
import entity.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;

/**
 * Panel Quản Lý Ca Làm – thiết kế nghiệp vụ v2.
 *
 * <p><b>Luồng nghiệp vụ:</b>
 * <ol>
 *   <li>Nhân viên đăng ký ca (tab Đăng Ký Ca)</li>
 *   <li>Quản lý duyệt đăng ký → hệ thống generate lịch thực tế</li>
 *   <li>Xem lịch theo ngày: ca nào – trạng thái – nhân viên nào</li>
 *   <li>Chỉnh sửa thủ công: nghỉ / đổi ca / OT / đi trễ</li>
 * </ol>
 *
 * <p><b>4 entity:</b> CaLam → DangKyCa → CaLamTheoNgay → LichLamViec
 */
public class QuanLyCaLam extends JPanel {

    // ── Màu sắc ──────────────────────────────────────────────────────────
    private static final Color MAIN_BLUE    = Color.decode("#0B3D59");
    private static final Color GOLD         = Color.decode("#C5A059");
    private static final Color TEXT_DARK    = Color.decode("#333333");
    private static final Color BORDER_CLR   = Color.decode("#E0E0E0");
    private static final Color SELECT_BG    = Color.decode("#EBF5FB");
    private static final Color GREEN_BTN    = Color.decode("#27AE60");
    private static final Color RED_BTN      = Color.decode("#E74C3C");
    private static final Color ORANGE_BTN   = Color.decode("#E67E22");
    private static final Color CYAN_BTN     = Color.decode("#1ABC9C");
    private static final Color HEADER_BG    = Color.decode("#F0F4F8");
    private static final Color TODAY_BG     = Color.decode("#FFF9C4");
    private static final Color SHIFT_BG     = Color.decode("#FFFDE7");
    private static final Color GRAY_TEXT    = new Color(120, 120, 120);

    // ── Trạng thái màu ────────────────────────────────────────────────────
    private static final Color CLR_CHUA     = Color.decode("#95A5A6");
    private static final Color CLR_MO       = Color.decode("#27AE60");
    private static final Color CLR_PHUC_VU  = Color.decode("#2980B9");
    private static final Color CLR_KET_THUC = Color.decode("#E67E22");
    private static final Color CLR_DONG     = Color.decode("#7F8C8D");

    // ── DAOs ─────────────────────────────────────────────────────────────
    private final CaLam_DAO          caDao     = new CaLam_DAO();
    private final DangKyCa_DAO       dkDao     = new DangKyCa_DAO();
    private final CaLamTheoNgay_DAO  cnDao     = new CaLamTheoNgay_DAO();
    private final LichLamViec_DAO    lichDao   = new LichLamViec_DAO();
    private final NhanVien_DAO       nvDao     = new NhanVien_DAO();

    // ── Cache ─────────────────────────────────────────────────────────────
    private List<CaLam>     dsCaLam    = new ArrayList<>();
    private List<NhanVien>  dsNhanVien = new ArrayList<>();
    private List<DangKyCa>  dsDangKy   = new ArrayList<>();

    // ── Tab components ────────────────────────────────────────────────────
    private JTabbedPane tabPane;

    // Tab 1: Lịch theo ngày
    private JTextField  txtNgayXem;
    private JPanel      pnLichNgay;

    // Tab 2: Đăng ký ca
    private JComboBox<String>   cmbNhanVienDK;
    private JComboBox<CaLam>    cmbCaLamDK;
    private JTextField          txtNgayBatDauDK;
    private JTextField          txtNgayKetThucDK;
    private JTextField          txtDanhSachThu;
    private DefaultTableModel   modelDangKy;
    private JTable              tableDangKy;
    private List<DangKyCa>      cachedDangKy = new ArrayList<>();

    // Tab 3: Quản lý lịch thực tế
    private JTextField          txtNgayLich;
    private JComboBox<String>   cmbCaFilter;
    private DefaultTableModel   modelLich;
    private JTable              tableLich;
    private List<LichLamViec>   cachedLich   = new ArrayList<>();

    private final SimpleDateFormat dateFmt = new SimpleDateFormat("dd/MM/yyyy");

    // ════════════════════════════════════════════════════════════════════════
    //  CONSTRUCTOR
    // ════════════════════════════════════════════════════════════════════════

    public QuanLyCaLam() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(10, 14, 10, 14));

        add(buildHeader(), BorderLayout.NORTH);

        tabPane = new JTabbedPane();
        tabPane.setFont(new Font("Segoe UI", Font.BOLD, 13));
        tabPane.addTab("  Lịch theo ngày",     buildTabLichNgay());
        tabPane.addTab("  Đăng ký ca",          buildTabDangKy());
        tabPane.addTab("  Quản lý lịch thực tế", buildTabLichThucTe());

        add(tabPane, BorderLayout.CENTER);
        loadDataAsync();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  HEADER
    // ════════════════════════════════════════════════════════════════════════

    private JPanel buildHeader() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(MAIN_BLUE);
        p.setBorder(new EmptyBorder(10, 16, 10, 16));
        JLabel lbl = new JLabel("QUẢN LÝ CA LÀM");
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lbl.setForeground(Color.WHITE);
        JLabel sub = new JLabel("Nhà hàng GoldenPearl •  Ca cố định: Sáng · Chiều · Tối");
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        sub.setForeground(new Color(200, 220, 240));
        p.add(lbl, BorderLayout.WEST);
        p.add(sub, BorderLayout.EAST);
        return p;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  TAB 1: LỊCH THEO NGÀY
    // ════════════════════════════════════════════════════════════════════════

    private JPanel buildTabLichNgay() {
        JPanel root = new JPanel(new BorderLayout(0, 8));
        root.setBackground(Color.WHITE);
        root.setBorder(new EmptyBorder(10, 10, 10, 10));

        // Thanh chọn ngày
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        bar.setBackground(Color.WHITE);
        bar.setBorder(new MatteBorder(0, 0, 1, 0, BORDER_CLR));

        txtNgayXem = mkField(110);
        txtNgayXem.setText(dateFmt.format(new java.util.Date()));
        txtNgayXem.setHorizontalAlignment(SwingConstants.CENTER);

        JButton btnPickNgay  = mkIconBtn("Chọn");
        JButton btnHomNay    = mkBtn("Hôm nay",   MAIN_BLUE,  Color.WHITE, 200);
        JButton btnHom_Truoc = mkIconBtn("-");
        JButton btnHom_Sau   = mkIconBtn("+");
        JButton btnXemLich   = mkBtn("Xem lịch",  GREEN_BTN,  Color.WHITE, 200);
        JButton btnMoNgay    = mkBtn("Mở ngày",   GOLD,       MAIN_BLUE,  200);

        btnPickNgay.addActionListener(e  -> showDatePicker(txtNgayXem, null));
        btnHomNay.addActionListener(e    -> { txtNgayXem.setText(dateFmt.format(new java.util.Date())); loadLichNgay(); });
        btnHom_Truoc.addActionListener(e -> shiftDate(txtNgayXem, -1));
        btnHom_Sau.addActionListener(e   -> shiftDate(txtNgayXem, +1));
        btnXemLich.addActionListener(e   -> loadLichNgay());
        btnMoNgay.addActionListener(e    -> handleMoNgay());

        bar.add(new JLabel("Ngày:"));
        bar.add(btnHom_Truoc);
        bar.add(txtNgayXem);
        bar.add(btnPickNgay);
        bar.add(btnHom_Sau);
        bar.add(Box.createHorizontalStrut(6));
        bar.add(btnHomNay);
        bar.add(btnXemLich);
        bar.add(Box.createHorizontalStrut(12));
        bar.add(btnMoNgay);

        root.add(bar, BorderLayout.NORTH);

        // Panel hiển thị lịch ngày (3 cột: Ca Sáng / Ca Chiều / Ca Tối)
        pnLichNgay = new JPanel(new GridLayout(1, 3, 8, 0));
        pnLichNgay.setBackground(Color.WHITE);

        JScrollPane scroll = new JScrollPane(pnLichNgay);
        scroll.setBorder(BorderFactory.createLineBorder(BORDER_CLR));
        root.add(scroll, BorderLayout.CENTER);

        return root;
    }

    /**
     * Load và render lịch làm việc theo ngày đang chọn.
     * Hiển thị: mỗi ca 1 cột, mỗi cột có trạng thái ca + danh sách NV.
     */
    private void loadLichNgay() {
        Date ngay = parseDateSQL(txtNgayXem.getText());
        if (ngay == null) { JOptionPane.showMessageDialog(this, "Ngày không hợp lệ!"); return; }

        pnLichNgay.removeAll();

        SwingWorker<LinkedHashMap<CaLamTheoNgay, List<LichLamViec>>, Void> worker =
                new SwingWorker<>() {
                    @Override
                    protected LinkedHashMap<CaLamTheoNgay, List<LichLamViec>> doInBackground() {
                        return lichDao.getLichTheoNgayNhomTheoCa(ngay);
                    }
                    @Override
                    protected void done() {
                        try {
                            LinkedHashMap<CaLamTheoNgay, List<LichLamViec>> map = get();
                            if (map.isEmpty()) {
                                JLabel hint = new JLabel(
                                        "<html><center>Chưa có dữ liệu ca làm cho ngày này.<br>"
                                                + "Nhấn <b>Mở ngày</b> để tạo ca.</center></html>",
                                        SwingConstants.CENTER);
                                hint.setForeground(GRAY_TEXT);
                                hint.setFont(new Font("Segoe UI", Font.PLAIN, 13));
                                pnLichNgay.setLayout(new BorderLayout());
                                pnLichNgay.add(hint, BorderLayout.CENTER);
                            } else {
                                pnLichNgay.setLayout(new GridLayout(1, map.size(), 8, 0));
                                for (Map.Entry<CaLamTheoNgay, List<LichLamViec>> e : map.entrySet()) {
                                    pnLichNgay.add(buildCaCard(e.getKey(), e.getValue(), ngay));
                                }
                            }
                            pnLichNgay.revalidate();
                            pnLichNgay.repaint();
                        } catch (Exception ex) { ex.printStackTrace(); }
                    }
                };
        worker.execute();
    }

    /**
     * Xây dựng card hiển thị một ca trong ngày.
     *
     * <pre>
     * ┌──────────────────────────┐
     * │  CA SÁNG  06:00–14:00    │
     * │  [ĐANG MỞ]               │
     * ├──────────────────────────┤
     * │  • Nguyễn Văn A          │
     * │  • Trần Thị B  [Đi trễ] │
     * └──────────────────────────┘
     * </pre>
     */
    private JPanel buildCaCard(CaLamTheoNgay cn, List<LichLamViec> dsNV, Date ngay) {
        JPanel card = new JPanel(new BorderLayout(0, 4));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_CLR, 1),
                new EmptyBorder(0, 0, 8, 0)));

        // --- Header ca ---
        Color headerColor = trangThaiColor(cn.getTrangThai());
        JPanel header = new JPanel(new BorderLayout(4, 0));
        header.setBackground(headerColor);
        header.setBorder(new EmptyBorder(8, 10, 8, 10));

        String tenCa = cn.getTenCaDisplay().toUpperCase();
        String gio   = cn.getGioBatDauDisplay() + "–" + cn.getGioKetThucDisplay();
        JLabel lblCa = new JLabel(tenCa + "  " + gio);
        lblCa.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblCa.setForeground(Color.WHITE);

        JLabel lblTT = new JLabel(cn.getTrangThai() != null ? cn.getTrangThai() : "");
        lblTT.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblTT.setForeground(new Color(220, 240, 255));
        lblTT.setHorizontalAlignment(SwingConstants.RIGHT);

        header.add(lblCa, BorderLayout.WEST);
        header.add(lblTT, BorderLayout.EAST);
        card.add(header, BorderLayout.NORTH);

        // --- Danh sách nhân viên ---
        JPanel pnNV = new JPanel();
        pnNV.setLayout(new BoxLayout(pnNV, BoxLayout.Y_AXIS));
        pnNV.setBackground(Color.WHITE);
        pnNV.setBorder(new EmptyBorder(8, 10, 4, 10));

        if (dsNV.isEmpty()) {
            JLabel empty = new JLabel("(Chưa có nhân viên)");
            empty.setForeground(GRAY_TEXT);
            empty.setFont(new Font("Segoe UI", Font.ITALIC, 12));
            pnNV.add(empty);
        } else {
            for (LichLamViec l : dsNV) {
                pnNV.add(buildNhanVienRow(l, cn, ngay));
                pnNV.add(Box.createVerticalStrut(2));
            }
        }

        // Nút thêm NV vào ca này
        JButton btnThemNV = new JButton("+ Thêm nhân viên");
        btnThemNV.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        btnThemNV.setForeground(MAIN_BLUE);
        btnThemNV.setBackground(Color.WHITE);
        btnThemNV.setBorder(BorderFactory.createLineBorder(BORDER_CLR));
        btnThemNV.setFocusPainted(false);
        btnThemNV.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnThemNV.addActionListener(e -> showThemNVDialog(cn, ngay));

        JPanel btmPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 4));
        btmPanel.setBackground(Color.WHITE);
        btmPanel.add(btnThemNV);

        // Nút đổi trạng thái ca
        JButton btnDoiTT = new JButton("Đổi trạng thái ca ▼");
        btnDoiTT.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        btnDoiTT.setForeground(GRAY_TEXT);
        btnDoiTT.setBackground(Color.WHITE);
        btnDoiTT.setBorder(BorderFactory.createLineBorder(BORDER_CLR));
        btnDoiTT.setFocusPainted(false);
        btnDoiTT.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnDoiTT.addActionListener(e -> showDoiTrangThaiCa(cn));
        btmPanel.add(btnDoiTT);

        card.add(new JScrollPane(pnNV,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER), BorderLayout.CENTER);
        card.add(btmPanel, BorderLayout.SOUTH);
        return card;
    }

    private JPanel buildNhanVienRow(LichLamViec l, CaLamTheoNgay cn, Date ngay) {
        JPanel row = new JPanel(new BorderLayout(4, 0));
        row.setBackground(Color.WHITE);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));

        String ten = l.getTenNhanVien() != null ? l.getTenNhanVien() : l.getMaNhanVien();
        JLabel lblTen = new JLabel("• " + ten);
        lblTen.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        row.add(lblTen, BorderLayout.CENTER);

        // Badge trạng thái nhân viên
        if (l.getTrangThai() != null && !l.getTrangThai().equals(LichLamViec.TT_LAM_VIEC)) {
            JLabel badge = new JLabel(l.getTrangThai());
            badge.setFont(new Font("Segoe UI", Font.BOLD, 10));
            badge.setForeground(nhanVienTrangThaiColor(l.getTrangThai()));
            badge.setBorder(BorderFactory.createLineBorder(nhanVienTrangThaiColor(l.getTrangThai())));
            row.add(badge, BorderLayout.EAST);
        }

        // Click để chỉnh sửa trạng thái NV
        row.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        row.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                showEditLichDialog(l, ngay);
            }
        });
        return row;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  TAB 2: ĐĂNG KÝ CA
    // ════════════════════════════════════════════════════════════════════════

    private JPanel buildTabDangKy() {
        JPanel root = new JPanel(new BorderLayout(8, 0));
        root.setBackground(Color.WHITE);
        root.setBorder(new EmptyBorder(10, 10, 10, 10));

        root.add(buildDangKyForm(),  BorderLayout.WEST);
        root.add(buildDangKyTable(), BorderLayout.CENTER);
        return root;
    }

    private JPanel buildDangKyForm() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(Color.WHITE);
        root.setPreferredSize(new Dimension(260, 0));
        root.setBorder(new MatteBorder(0, 0, 0, 1, BORDER_CLR));

        JLabel title = mkSectionTitle("ĐĂNG KÝ CA MỚI");
        root.add(title, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Color.WHITE);
        form.setBorder(new EmptyBorder(10, 10, 10, 10));
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL; g.weightx = 1;
        g.insets = new Insets(3, 0, 3, 0);

        cmbNhanVienDK = new JComboBox<>();
        cmbNhanVienDK.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        cmbNhanVienDK.setPreferredSize(new Dimension(0, 30));

        cmbCaLamDK = new JComboBox<>();
        cmbCaLamDK.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        cmbCaLamDK.setPreferredSize(new Dimension(0, 30));

        txtNgayBatDauDK  = mkField(0); txtNgayBatDauDK.setText(dateFmt.format(new java.util.Date()));
        txtNgayKetThucDK = mkField(0);
        txtDanhSachThu   = mkField(0);
        txtDanhSachThu.setToolTipText("VD: 2,3,4,5,6 (Thứ 2→6). Để trống = tất cả ngày.");

        JPanel rowBD = buildDateRow(txtNgayBatDauDK);
        JPanel rowKT = buildDateRow(txtNgayKetThucDK);

        int r = 0;
        addFormRow(form, g, r++, "Nhân viên:",       cmbNhanVienDK);
        addFormRow(form, g, r++, "Ca làm:",          cmbCaLamDK);
        addFormRow(form, g, r++, "Từ ngày:",         rowBD);
        addFormRow(form, g, r++, "Đến ngày:",        rowKT);
        addFormRow(form, g, r++, "Các thứ (2–7,CN=1):", txtDanhSachThu);

        // Hint
        JLabel hint = new JLabel("<html><i style='color:gray'>Để trống = làm tất cả các ngày</i></html>");
        hint.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        g.gridy = r * 2 + 1; form.add(hint, g);

        g.gridy = (r + 1) * 2; g.weighty = 1;
        form.add(Box.createVerticalGlue(), g);

        root.add(new JScrollPane(form,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER), BorderLayout.CENTER);

        // Buttons
        JPanel btns = new JPanel(new GridLayout(1, 2, 6, 0));
        btns.setBackground(Color.WHITE);
        btns.setBorder(new CompoundBorder(
                new MatteBorder(1, 0, 0, 0, BORDER_CLR),
                new EmptyBorder(10, 10, 10, 10)));
        JButton btnTao    = mkBtn("Tạo đăng ký", GREEN_BTN, Color.WHITE, 180);
        JButton btnLamMoi = mkBtn("Làm mới",     CYAN_BTN,  Color.WHITE, 180);
        btnTao.addActionListener(e    -> handleTaoDangKy());
        btnLamMoi.addActionListener(e -> clearDangKyForm());
        btns.add(btnTao); btns.add(btnLamMoi);
        root.add(btns, BorderLayout.SOUTH);

        return root;
    }

    private JPanel buildDangKyTable() {
        JPanel p = new JPanel(new BorderLayout(0, 4));
        p.setBackground(Color.WHITE);
        p.add(mkSectionTitle("DANH SÁCH ĐĂNG KÝ CA"), BorderLayout.NORTH);

        String[] cols = {"Mã đăng ký", "Nhân viên", "Ca", "Từ ngày", "Đến ngày", "Các thứ", "Trạng thái"};
        modelDangKy = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tableDangKy = new JTable(modelDangKy);
        styleTable(tableDangKy);
        tableDangKy.getColumnModel().getColumn(0).setPreferredWidth(155);
        tableDangKy.getColumnModel().getColumn(6).setPreferredWidth(100);

        // Thanh hành động duyệt/từ chối
        JPanel actionBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        actionBar.setBackground(Color.WHITE);
        actionBar.setBorder(new MatteBorder(0, 0, 1, 0, BORDER_CLR));

        JButton btnDuyet    = mkBtn("✓ Duyệt & Generate lịch", GREEN_BTN,  Color.WHITE, 200);
        JButton btnTuChoi   = mkBtn("✗ Từ chối",               RED_BTN,    Color.WHITE, 200);
        JButton btnHuy      = mkBtn("Hủy đăng ký",             ORANGE_BTN, Color.WHITE, 200);
        JButton btnRefresh  = mkBtn("↺ Tải lại",               MAIN_BLUE,  Color.WHITE, 200);

        btnDuyet.addActionListener(e   -> handleDuyetDangKy());
        btnTuChoi.addActionListener(e  -> handleTuChoiDangKy());
        btnHuy.addActionListener(e     -> handleHuyDangKy());
        btnRefresh.addActionListener(e -> loadDangKyData());

        actionBar.add(btnDuyet); actionBar.add(btnTuChoi);
        actionBar.add(btnHuy);   actionBar.add(btnRefresh);
        p.add(actionBar, BorderLayout.SOUTH);

        JScrollPane scroll = new JScrollPane(tableDangKy);
        scroll.setBorder(BorderFactory.createLineBorder(BORDER_CLR));
        p.add(scroll, BorderLayout.CENTER);

        return p;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  TAB 3: QUẢN LÝ LỊCH THỰC TẾ
    // ════════════════════════════════════════════════════════════════════════

    private JPanel buildTabLichThucTe() {
        JPanel root = new JPanel(new BorderLayout(0, 8));
        root.setBackground(Color.WHITE);
        root.setBorder(new EmptyBorder(10, 10, 10, 10));

        // Thanh lọc
        JPanel filter = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        filter.setBackground(Color.WHITE);
        filter.setBorder(new MatteBorder(0, 0, 1, 0, BORDER_CLR));

        txtNgayLich = mkField(110);
        txtNgayLich.setText(dateFmt.format(new java.util.Date()));
        txtNgayLich.setHorizontalAlignment(SwingConstants.CENTER);

        cmbCaFilter = new JComboBox<>(new String[]{"Tất cả ca"});
        cmbCaFilter.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        cmbCaFilter.setPreferredSize(new Dimension(140, 30));

        JButton btnPickNgay = mkIconBtn("📅");
        JButton btnXem      = mkBtn("Xem",   MAIN_BLUE, Color.WHITE, 80);
        btnPickNgay.addActionListener(e -> showDatePicker(txtNgayLich, null));
        btnXem.addActionListener(e      -> loadLichThucTeData());

        filter.add(new JLabel("Ngày:")); filter.add(txtNgayLich); filter.add(btnPickNgay);
        filter.add(new JLabel("Ca:"));   filter.add(cmbCaFilter);
        filter.add(btnXem);
        root.add(filter, BorderLayout.NORTH);

        // Bảng lịch
        String[] cols = {"Mã NV", "Tên nhân viên", "Ca làm", "Ngày làm", "Giờ", "Trạng thái NV", "Ghi chú"};
        modelLich = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tableLich = new JTable(modelLich);
        styleTable(tableLich);

        JScrollPane scroll = new JScrollPane(tableLich);
        scroll.setBorder(BorderFactory.createLineBorder(BORDER_CLR));
        root.add(scroll, BorderLayout.CENTER);

        // Action bar
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        bar.setBackground(Color.WHITE);
        bar.setBorder(new MatteBorder(1, 0, 0, 0, BORDER_CLR));

        JButton btnThemTT  = mkBtn(" Thêm thủ công",  GREEN_BTN,  Color.WHITE, 200);
        JButton btnSuaTT   = mkBtn(" Sửa trạng thái", GOLD,       MAIN_BLUE,  200);
        JButton btnXoaTT   = mkBtn(" Xóa",            RED_BTN,    Color.WHITE, 200);
        JButton btnRefresh = mkBtn(" Tải lại",         MAIN_BLUE,  Color.WHITE, 200);

        btnThemTT.addActionListener(e  -> showThemLichThuCong());
        btnSuaTT.addActionListener(e   -> handleSuaTrangThaiLich());
        btnXoaTT.addActionListener(e   -> handleXoaLich());
        btnRefresh.addActionListener(e -> loadLichThucTeData());

        bar.add(btnThemTT); bar.add(btnSuaTT); bar.add(btnXoaTT); bar.add(btnRefresh);
        root.add(bar, BorderLayout.SOUTH);

        return root;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  LOAD DATA
    // ════════════════════════════════════════════════════════════════════════

    private void loadDataAsync() {
        new SwingWorker<Object[], Void>() {
            @Override protected Object[] doInBackground() {
                return new Object[]{
                        caDao.getAll(),
                        nvDao.getAllNhanVien(),
                        dkDao.getAll()
                };
            }
            @Override @SuppressWarnings("unchecked") protected void done() {
                try {
                    Object[] r = get();
                    dsCaLam    = (List<CaLam>)    r[0];
                    dsNhanVien = (List<NhanVien>)  r[1];
                    dsDangKy   = (List<DangKyCa>)  r[2];

                    // Đổ dữ liệu vào combobox
                    cmbCaLamDK.removeAllItems();
                    for (CaLam ca : dsCaLam) cmbCaLamDK.addItem(ca);

                    cmbNhanVienDK.removeAllItems();
                    for (NhanVien nv : dsNhanVien)
                        cmbNhanVienDK.addItem(nv.getMaNV() + " – " + nv.getTenNV());

                    cmbCaFilter.removeAllItems();
                    cmbCaFilter.addItem("Tất cả ca");
                    for (CaLam ca : dsCaLam) cmbCaFilter.addItem(ca.getMaCa() + " – " + ca.getTenCa());

                    populateDangKyTable(dsDangKy);
                    loadLichNgay();
                } catch (Exception ex) { ex.printStackTrace(); }
            }
        }.execute();
    }

    private void loadDangKyData() {
        new SwingWorker<List<DangKyCa>, Void>() {
            @Override protected List<DangKyCa> doInBackground() { return dkDao.getAll(); }
            @Override protected void done() {
                try { populateDangKyTable(get()); } catch (Exception ex) { ex.printStackTrace(); }
            }
        }.execute();
    }

    private void loadLichThucTeData() {
        Date ngay = parseDateSQL(txtNgayLich.getText());
        if (ngay == null) return;
        String caFilter = (String) cmbCaFilter.getSelectedItem();

        new SwingWorker<List<LichLamViec>, Void>() {
            @Override protected List<LichLamViec> doInBackground() {
                return lichDao.getByNgay(ngay);
            }
            @Override protected void done() {
                try {
                    cachedLich = get();
                    modelLich.setRowCount(0);
                    for (LichLamViec l : cachedLich) {
                        CaLamTheoNgay cn = l.getCaNgay();
                        if (cn == null) continue;
                        // Lọc ca nếu cần
                        if (caFilter != null && !caFilter.equals("Tất cả ca")) {
                            String maCa = caFilter.split("–")[0].trim();
                            if (!cn.getMaCa().equals(maCa)) continue;
                        }
                        String gio = cn.getGioBatDauDisplay() + "–" + cn.getGioKetThucDisplay();
                        modelLich.addRow(new Object[]{
                                l.getMaNhanVien(),
                                nullSafe(l.getTenNhanVien()),
                                cn.getTenCaDisplay(),
                                new SimpleDateFormat("dd/MM/yyyy").format(cn.getNgayLam()),
                                gio,
                                l.getTrangThai(),
                                nullSafe(l.getGhiChu())
                        });
                    }
                } catch (Exception ex) { ex.printStackTrace(); }
            }
        }.execute();
    }

    private void populateDangKyTable(List<DangKyCa> ds) {
        cachedDangKy = ds;
        modelDangKy.setRowCount(0);
        SimpleDateFormat fmt = new SimpleDateFormat("dd/MM/yyyy");
        for (DangKyCa dk : ds) {
            modelDangKy.addRow(new Object[]{
                    dk.getMaDangKy(),
                    dk.getMaNhanVien(),
                    dk.getMaCa(),
                    dk.getNgayBatDau() != null ? fmt.format(dk.getNgayBatDau()) : "",
                    dk.getNgayKetThuc() != null ? fmt.format(dk.getNgayKetThuc()) : "",
                    dk.getDanhSachThu() != null ? dk.getDanhSachThu() : "Tất cả",
                    dk.getTrangThai()
            });
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  ACTION HANDLERS – ĐĂNG KÝ CA
    // ════════════════════════════════════════════════════════════════════════

    private void handleTaoDangKy() {
        int nvIdx = cmbNhanVienDK.getSelectedIndex();
        CaLam ca  = (CaLam) cmbCaLamDK.getSelectedItem();
        if (nvIdx < 0 || dsNhanVien.isEmpty() || ca == null) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn nhân viên và ca làm!");
            return;
        }
        Date bd = parseDateSQL(txtNgayBatDauDK.getText());
        Date kt = parseDateSQL(txtNgayKetThucDK.getText());
        if (bd == null || kt == null) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập đúng định dạng ngày (dd/MM/yyyy)!");
            return;
        }
        if (kt.before(bd)) {
            JOptionPane.showMessageDialog(this, "Ngày kết thúc phải sau ngày bắt đầu!");
            return;
        }

        NhanVien nv = dsNhanVien.get(nvIdx);
        String thu  = txtDanhSachThu.getText().trim();

        DangKyCa dk = new DangKyCa();
        dk.setMaNhanVien(nv.getMaNV());
        dk.setMaCa(ca.getMaCa());
        dk.setNgayBatDau(bd);
        dk.setNgayKetThuc(kt);
        dk.setDanhSachThu(thu.isEmpty() ? null : thu);
        dk.setTrangThai("Chờ duyệt");

        int id = dkDao.create(dk);
        try {
            id = dkDao.create(dk);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "❌ Đã tồn tại đăng ký ca này!\nVui lòng kiểm tra lại.", "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (id > 0) {
            JOptionPane.showMessageDialog(this,
                    "✅ Tạo đăng ký thành công!\nMã: " + dk.getMaDangKy());
            clearDangKyForm();
            loadDangKyData();
        } else {
            JOptionPane.showMessageDialog(this, "❌ Lỗi tạo đăng ký!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleDuyetDangKy() {
        int row = tableDangKy.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Chọn đăng ký cần duyệt!"); return; }
        DangKyCa dk = cachedDangKy.get(row);
        if (!"Chờ duyệt".equals(dk.getTrangThai())) {
            JOptionPane.showMessageDialog(this, "Chỉ duyệt được đăng ký đang ở trạng thái 'Chờ duyệt'!");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "<html>Duyệt đăng ký: <b>" + dk.getMaDangKy() + "</b><br>"
                        + "Hệ thống sẽ tự động generate lịch làm việc.<br>"
                        + "Tiếp tục?</html>",
                "Xác nhận duyệt", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        // Cập nhật trạng thái → Đã duyệt
        dkDao.updateTrangThai(dk.getIdDangKy(), "Đã duyệt");
        dk.setTrangThai("Đã duyệt");

        // Generate CaLamTheoNgay
        int cnCount = cnDao.generateFromDangKy(dk);

        // Generate LichLamViec
        int lichCount = lichDao.generateFromDangKy(dk);

        JOptionPane.showMessageDialog(this,
                "✅ Đã duyệt thành công!\n"
                        + "Generate: " + cnCount + " ca theo ngày, " + lichCount + " lịch làm việc.");
        loadDangKyData();
        loadLichNgay();
    }

    private void handleTuChoiDangKy() {
        int row = tableDangKy.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Chọn đăng ký!"); return; }
        DangKyCa dk = cachedDangKy.get(row);
        dkDao.updateTrangThai(dk.getIdDangKy(), "Từ chối");
        loadDangKyData();
    }

    private void handleHuyDangKy() {
        int row = tableDangKy.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Chọn đăng ký!"); return; }
        DangKyCa dk = cachedDangKy.get(row);

        if ("Đã duyệt".equals(dk.getTrangThai())) {
            int confirm = JOptionPane.showConfirmDialog(this,
                    "<html>Đăng ký này đã được duyệt và có thể đã có lịch thực tế.<br>"
                            + "Chuyển sang trạng thái <b>Đã hủy</b>?</html>",
                    "Xác nhận hủy", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (confirm != JOptionPane.YES_OPTION) return;
            dkDao.updateTrangThai(dk.getIdDangKy(), "Đã hủy");
            JOptionPane.showMessageDialog(this, "✅ Đã chuyển sang trạng thái Đã hủy.");
            loadDangKyData();
            return;
        }

        // Chờ duyệt / Từ chối → xóa thẳng
        if (dkDao.delete(dk.getIdDangKy())) {
            JOptionPane.showMessageDialog(this, "✅ Đã xóa đăng ký.");
            loadDangKyData();
        } else {
            JOptionPane.showMessageDialog(this, "Không thể xóa!", "Lỗi", JOptionPane.WARNING_MESSAGE);
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  ACTION HANDLERS – LỊCH THỰC TẾ
    // ════════════════════════════════════════════════════════════════════════

    private void handleMoNgay() {
        Date ngay = parseDateSQL(txtNgayXem.getText());
        if (ngay == null) { JOptionPane.showMessageDialog(this, "Ngày không hợp lệ!"); return; }
        int count = cnDao.generateAllCaForNgay(ngay, dsCaLam);
        if (count > 0) {
            JOptionPane.showMessageDialog(this, "✅ Đã tạo " + count + " ca cho ngày " + txtNgayXem.getText());
        } else {
            JOptionPane.showMessageDialog(this, "Ngày này đã có ca (không tạo lại).");
        }
        loadLichNgay();
    }

    private void handleSuaTrangThaiLich() {
        int row = tableLich.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Chọn lịch cần sửa!"); return; }
        LichLamViec l = cachedLich.get(row);
        showEditLichDialog(l, parseDateSQL(txtNgayLich.getText()));
    }

    private void handleXoaLich() {
        int row = tableLich.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Chọn lịch cần xóa!"); return; }
        int confirm = JOptionPane.showConfirmDialog(this, "Xóa lịch này?", "Xác nhận", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;
        LichLamViec l = cachedLich.get(row);
        if (lichDao.delete(l.getIdLich())) {
            loadLichThucTeData();
            loadLichNgay();
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  DIALOG – THÊM NV VÀO CA
    // ════════════════════════════════════════════════════════════════════════

    private void showThemNVDialog(CaLamTheoNgay cn, Date ngay) {
        JDialog dlg = new JDialog((Frame) SwingUtilities.getWindowAncestor(this),
                "Thêm nhân viên – " + cn.getTenCaDisplay() + " (" +
                        new SimpleDateFormat("dd/MM/yyyy").format(ngay) + ")", true);
        dlg.setSize(320, 200);
        dlg.setLocationRelativeTo(this);
        dlg.getContentPane().setBackground(Color.WHITE);
        dlg.setLayout(new BorderLayout(0, 8));

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Color.WHITE);
        form.setBorder(new EmptyBorder(12, 16, 8, 16));
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL; g.weightx = 1; g.insets = new Insets(4, 0, 4, 0);

        JComboBox<String> cmbNV = new JComboBox<>();
        for (NhanVien nv : dsNhanVien) cmbNV.addItem(nv.getMaNV() + " – " + nv.getTenNV());
        cmbNV.setFont(new Font("Segoe UI", Font.PLAIN, 12));

        String[] ttOptions = {LichLamViec.TT_LAM_VIEC, LichLamViec.TT_TANG_CUONG, LichLamViec.TT_OT};
        JComboBox<String> cmbTT = new JComboBox<>(ttOptions);

        g.gridy = 0; form.add(new JLabel("Nhân viên:"), g);
        g.gridy = 1; form.add(cmbNV, g);
        g.gridy = 2; form.add(new JLabel("Trạng thái:"), g);
        g.gridy = 3; form.add(cmbTT, g);
        dlg.add(form, BorderLayout.CENTER);

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 8));
        btns.setBackground(Color.WHITE);
        JButton btnCancel = mkBtn("Hủy",  Color.WHITE, TEXT_DARK, 100);
        btnCancel.setBorder(BorderFactory.createLineBorder(BORDER_CLR));
        JButton btnSave   = mkBtn("Thêm", GREEN_BTN,   Color.WHITE, 100);

        btnCancel.addActionListener(e -> dlg.dispose());
        btnSave.addActionListener(e -> {
            int idx = cmbNV.getSelectedIndex();
            if (idx < 0 || dsNhanVien.isEmpty()) return;
            NhanVien nv = dsNhanVien.get(idx);
            LichLamViec l = new LichLamViec();
            l.setIdCaNgay(cn.getIdCaNgay());
            l.setMaNhanVien(nv.getMaNV());
            l.setTrangThai((String) cmbTT.getSelectedItem());
            int id = lichDao.create(l);
            if (id > 0) {
                JOptionPane.showMessageDialog(dlg, "✅ Đã thêm nhân viên vào ca!");
                dlg.dispose();
                loadLichNgay();
                loadLichThucTeData();
            } else {
                JOptionPane.showMessageDialog(dlg, "Lỗi! Nhân viên có thể đã có trong ca này.");
            }
        });
        btns.add(btnCancel); btns.add(btnSave);
        dlg.add(btns, BorderLayout.SOUTH);
        dlg.setVisible(true);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  DIALOG – SỬA TRẠNG THÁI LỊCH LÀM
    // ════════════════════════════════════════════════════════════════════════

    private void showEditLichDialog(LichLamViec l, Date ngay) {
        JDialog dlg = new JDialog((Frame) SwingUtilities.getWindowAncestor(this),
                "Sửa lịch – " + nullSafe(l.getTenNhanVien()), true);
        dlg.setSize(340, 240);
        dlg.setLocationRelativeTo(this);
        dlg.getContentPane().setBackground(Color.WHITE);
        dlg.setLayout(new BorderLayout());

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Color.WHITE);
        form.setBorder(new EmptyBorder(12, 16, 8, 16));
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL; g.weightx = 1; g.insets = new Insets(4, 0, 4, 0);

        String[] allTT = {
                LichLamViec.TT_LAM_VIEC,
                LichLamViec.TT_NGHI_PHEP,
                LichLamViec.TT_NGHI_KHONG_PHEP,
                LichLamViec.TT_DI_TRE,
                LichLamViec.TT_TANG_CUONG,
                LichLamViec.TT_OT,
                LichLamViec.TT_DOI_CA
        };
        JComboBox<String> cmbTT = new JComboBox<>(allTT);
        if (l.getTrangThai() != null) cmbTT.setSelectedItem(l.getTrangThai());

        JTextField txtGhiChu = mkField(0);
        txtGhiChu.setText(nullSafe(l.getGhiChu()));

        g.gridy = 0; form.add(new JLabel("Nhân viên: " + nullSafe(l.getTenNhanVien())), g);
        g.gridy = 2; form.add(new JLabel("Trạng thái:"), g);
        g.gridy = 3; form.add(cmbTT, g);
        g.gridy = 4; form.add(new JLabel("Ghi chú:"), g);
        g.gridy = 5; form.add(txtGhiChu, g);
        dlg.add(form, BorderLayout.CENTER);

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 8));
        btns.setBackground(Color.WHITE);
        JButton btnCancel = mkBtn("Hủy",  Color.WHITE, TEXT_DARK, 70);
        btnCancel.setBorder(BorderFactory.createLineBorder(BORDER_CLR));
        JButton btnSave   = mkBtn("Lưu",  MAIN_BLUE,   Color.WHITE, 70);
        btnCancel.addActionListener(e -> dlg.dispose());
        btnSave.addActionListener(e -> {
            String tt = (String) cmbTT.getSelectedItem();
            String gc = txtGhiChu.getText().trim();
            if (lichDao.updateTrangThai(l.getIdLich(), tt, gc)) {
                JOptionPane.showMessageDialog(dlg, "✅ Đã cập nhật!");
                dlg.dispose();
                loadLichNgay();
                loadLichThucTeData();
            }
        });
        btns.add(btnCancel); btns.add(btnSave);
        dlg.add(btns, BorderLayout.SOUTH);
        dlg.setVisible(true);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  DIALOG – ĐỔI TRẠNG THÁI CA
    // ════════════════════════════════════════════════════════════════════════

    private void showDoiTrangThaiCa(CaLamTheoNgay cn) {
        String[] options = {
                CaLamTheoNgay.TT_CHUA_BAT_DAU,
                CaLamTheoNgay.TT_DANG_MO,
                CaLamTheoNgay.TT_DANG_PHUC_VU,
                CaLamTheoNgay.TT_DA_KET_THUC,
                CaLamTheoNgay.TT_DA_DONG
        };
        String choice = (String) JOptionPane.showInputDialog(this,
                "Chọn trạng thái ca:", "Đổi trạng thái – " + cn.getTenCaDisplay(),
                JOptionPane.PLAIN_MESSAGE, null, options, cn.getTrangThai());
        if (choice != null) {
            cnDao.updateTrangThai(cn.getIdCaNgay(), choice);
            loadLichNgay();
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  DIALOG – THÊM LỊCH THỦ CÔNG
    // ════════════════════════════════════════════════════════════════════════

    private void showThemLichThuCong() {
        Date ngay = parseDateSQL(txtNgayLich.getText());
        if (ngay == null || dsCaLam.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn ngày hợp lệ!"); return;
        }
        List<CaLamTheoNgay> dsCaNgay = cnDao.getByNgay(ngay);
        if (dsCaNgay.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Chưa có ca nào cho ngày này. Hãy vào tab Lịch theo ngày → Mở ngày.");
            return;
        }
        showThemNVDialog(dsCaNgay.get(0), ngay);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  UTILS
    // ════════════════════════════════════════════════════════════════════════

    private void clearDangKyForm() {
        cmbNhanVienDK.setSelectedIndex(0);
        cmbCaLamDK.setSelectedIndex(0);
        txtNgayBatDauDK.setText(dateFmt.format(new java.util.Date()));
        txtNgayKetThucDK.setText("");
        txtDanhSachThu.setText("");
    }

    private void shiftDate(JTextField field, int days) {
        try {
            java.util.Date d = dateFmt.parse(field.getText());
            Calendar c = Calendar.getInstance(); c.setTime(d);
            c.add(Calendar.DAY_OF_MONTH, days);
            field.setText(dateFmt.format(c.getTime()));
            loadLichNgay();
        } catch (Exception ignored) {}
    }

    private Date parseDateSQL(String s) {
        try { return new Date(dateFmt.parse(s).getTime()); } catch (Exception e) { return null; }
    }

    private String nullSafe(String s) { return s == null ? "" : s; }

    private Color trangThaiColor(String tt) {
        if (tt == null) return CLR_CHUA;
        switch (tt) {
            case CaLamTheoNgay.TT_DANG_MO:       return CLR_MO;
            case CaLamTheoNgay.TT_DANG_PHUC_VU:  return CLR_PHUC_VU;
            case CaLamTheoNgay.TT_DA_KET_THUC:   return CLR_KET_THUC;
            case CaLamTheoNgay.TT_DA_DONG:        return CLR_DONG;
            default:                               return CLR_CHUA;
        }
    }

    private Color nhanVienTrangThaiColor(String tt) {
        if (tt == null) return GRAY_TEXT;
        switch (tt) {
            case LichLamViec.TT_NGHI_PHEP:
            case LichLamViec.TT_NGHI_KHONG_PHEP: return RED_BTN;
            case LichLamViec.TT_DI_TRE:          return ORANGE_BTN;
            case LichLamViec.TT_OT:
            case LichLamViec.TT_TANG_CUONG:      return CLR_PHUC_VU;
            default:                              return GREEN_BTN;
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  DATE PICKER
    // ════════════════════════════════════════════════════════════════════════

    @FunctionalInterface interface DateCB { void onSelected(java.util.Date d); }

    private void showDatePicker(JTextField target, DateCB cb) {
        JDialog dlg = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Chọn ngày", true);
        dlg.setSize(280, 300); dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout());
        dlg.getContentPane().setBackground(Color.WHITE);

        Calendar cal = Calendar.getInstance();
        try { if (!target.getText().isEmpty()) cal.setTime(dateFmt.parse(target.getText())); }
        catch (Exception ignored) {}

        JLabel lblM = new JLabel("", SwingConstants.CENTER);
        lblM.setFont(new Font("Segoe UI", Font.BOLD, 13));
        JPanel hdr = new JPanel(new BorderLayout(4, 4));
        hdr.setBackground(Color.WHITE); hdr.setBorder(new EmptyBorder(6, 8, 6, 8));
        JButton prev = mkIconBtn("◀"); JButton next = mkIconBtn("▶");
        hdr.add(prev, BorderLayout.WEST); hdr.add(lblM, BorderLayout.CENTER); hdr.add(next, BorderLayout.EAST);
        dlg.add(hdr, BorderLayout.NORTH);

        JPanel grid = new JPanel(new GridLayout(0, 7, 2, 2));
        grid.setBackground(Color.WHITE); grid.setBorder(new EmptyBorder(4, 8, 8, 8));
        dlg.add(grid, BorderLayout.CENTER);

        Runnable render = () -> {
            grid.removeAll();
            lblM.setText(new SimpleDateFormat("MM/yyyy").format(cal.getTime()));
            for (String s : new String[]{"CN","T2","T3","T4","T5","T6","T7"}) {
                JLabel l = new JLabel(s, SwingConstants.CENTER);
                l.setFont(new Font("Segoe UI", Font.BOLD, 11)); l.setForeground(MAIN_BLUE);
                grid.add(l);
            }
            Calendar tmp = (Calendar) cal.clone(); tmp.set(Calendar.DAY_OF_MONTH, 1);
            int off = tmp.get(Calendar.DAY_OF_WEEK) - 1;
            int max = tmp.getActualMaximum(Calendar.DAY_OF_MONTH);
            for (int i = 0; i < off; i++) grid.add(new JLabel(""));
            for (int d2 = 1; d2 <= max; d2++) {
                final Calendar dCal = (Calendar) cal.clone();
                dCal.set(Calendar.DAY_OF_MONTH, d2);
                JButton btn = new JButton(String.valueOf(d2));
                btn.setFont(new Font("Segoe UI", Font.PLAIN, 11));
                btn.setBackground(Color.WHITE); btn.setFocusPainted(false);
                btn.setBorder(BorderFactory.createLineBorder(new Color(220,220,220)));
                btn.setMargin(new Insets(2,2,2,2));
                btn.addActionListener(e2 -> {
                    target.setText(dateFmt.format(dCal.getTime()));
                    if (cb != null) cb.onSelected(dCal.getTime());
                    dlg.dispose();
                });
                grid.add(btn);
            }
            grid.revalidate(); grid.repaint();
        };
        render.run();
        prev.addActionListener(e -> { cal.add(Calendar.MONTH,-1); render.run(); });
        next.addActionListener(e -> { cal.add(Calendar.MONTH, 1); render.run(); });
        dlg.setVisible(true);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  UI FACTORY HELPERS
    // ════════════════════════════════════════════════════════════════════════

    private JTextField mkField(int w) {
        JTextField f = new JTextField();
        f.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        f.setBackground(Color.WHITE); f.setForeground(TEXT_DARK);
        f.setBorder(new CompoundBorder(
                BorderFactory.createLineBorder(BORDER_CLR),
                new EmptyBorder(2, 6, 2, 6)));
        f.setPreferredSize(new Dimension(w > 0 ? w : 100, 30));
        return f;
    }

    private JButton mkBtn(String t, Color bg, Color fg, int w) {
        JButton b = new JButton(t);
        b.setFont(new Font("Segoe UI", Font.BOLD, 12));
        b.setBackground(bg); b.setForeground(fg);
        b.setFocusPainted(false); b.setBorderPainted(false); b.setOpaque(true);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setPreferredSize(new Dimension(w > 0 ? w : 200, 30));
        return b;
    }

    private JButton mkIconBtn(String icon) {
        JButton b = new JButton(icon);
        b.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        b.setPreferredSize(new Dimension(30, 30));
        b.setFocusPainted(false);
        b.setBackground(Color.WHITE);
        b.setBorder(BorderFactory.createLineBorder(BORDER_CLR));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    private JLabel mkSectionTitle(String text) {
        JLabel l = new JLabel("  " + text);
        l.setFont(new Font("Segoe UI", Font.BOLD, 12));
        l.setForeground(MAIN_BLUE); l.setOpaque(true);
        l.setBackground(HEADER_BG);
        l.setPreferredSize(new Dimension(0, 28));
        l.setBorder(new MatteBorder(1, 0, 1, 0, BORDER_CLR));
        return l;
    }

    private JPanel buildDateRow(JTextField field) {
        JPanel p = new JPanel(new BorderLayout(2, 0));
        p.setBackground(Color.WHITE);
        JButton btn = mkIconBtn("📅");
        btn.addActionListener(e -> showDatePicker(field, null));
        p.add(field, BorderLayout.CENTER);
        p.add(btn, BorderLayout.EAST);
        return p;
    }

    private void addFormRow(JPanel p, GridBagConstraints g, int row, String lbl, Component comp) {
        g.gridy = row * 2;
        JLabel label = new JLabel(lbl);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        label.setForeground(GRAY_TEXT);
        p.add(label, g);
        g.gridy = row * 2 + 1;
        p.add(comp, g);
    }

    private void styleTable(JTable t) {
        t.setFont(new Font("Segoe UI", Font.PLAIN, 12)); t.setRowHeight(28);
        t.setSelectionBackground(SELECT_BG); t.setSelectionForeground(TEXT_DARK);
        t.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        t.getTableHeader().setBackground(HEADER_BG); t.getTableHeader().setForeground(MAIN_BLUE);
        t.getTableHeader().setPreferredSize(new Dimension(0, 30));
        t.setGridColor(BORDER_CLR); t.setBackground(Color.WHITE); t.setShowVerticalLines(false);
        t.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.LEFT);
        for (int i = 0; i < t.getColumnCount(); i++)
            t.getColumnModel().getColumn(i).setCellRenderer(center);
    }
}
