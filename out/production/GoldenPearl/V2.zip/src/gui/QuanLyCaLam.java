package gui;

import dao.CaLam_DAO;
import dao.LichLamViec_DAO;
import dao.NhanVien_DAO;
import entity.CaLam;
import entity.LichLamViec;
import entity.NhanVien;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;

/**
 * Panel quản lý Ca Làm và Lịch Làm Việc.
 *
 * <p>Bao gồm 2 tab:
 * <ol>
 *   <li><b>Quản Lý Ca</b> – CRUD danh sách ca (Ca sáng, Ca chiều…)</li>
 *   <li><b>Lịch Làm Việc</b> – phân công nhân viên theo ca + ngày</li>
 * </ol>
 */
public class QuanLyCaLam extends JPanel {

    // ── Tab 1: Ca Làm ───────────────────────────────────────────────────────
    private JTable            tableCaLam;
    private DefaultTableModel modelCaLam;
    private JTextField  txtMaCa, txtTenCa, txtGioBatDau, txtGioKetThuc;
    private JCheckBox   chkTrangThai;
    private JButton     btnThemCa, btnSuaCa, btnXoaCa, btnLamMoiCa;

    // ── Tab 2: Lịch Làm Việc ────────────────────────────────────────────────
    private JTable            tableLich;
    private DefaultTableModel modelLich;
    private JComboBox<String> cmbNhanVienLich;
    private JComboBox<String> cmbCaLich;
    private JTextField        txtNgayLam;
    private JTextField        txtGhiChu;
    private JButton           btnThemLich, btnXoaLich, btnLamMoiLich;
    private JButton           btnLocLich;
    private JComboBox<String> cmbLocCa;
    private JTextField        txtLocNgay;

    // ── DAOs ────────────────────────────────────────────────────────────────
    private final CaLam_DAO       caDao  = new CaLam_DAO();
    private final LichLamViec_DAO lichDao = new LichLamViec_DAO();
    private final NhanVien_DAO    nvDao  = new NhanVien_DAO();

    // ── Cache ───────────────────────────────────────────────────────────────
    private List<CaLam>    dsCaLam   = new ArrayList<>();
    private List<NhanVien> dsNhanVien = new ArrayList<>();

    // ── Colors ──────────────────────────────────────────────────────────────
    private static final Color TEXT_DARK    = Color.decode("#333333");
    private static final Color BORDER_COLOR = Color.decode("#E0E0E0");
    private static final Color MAIN_BLUE    = Color.decode("#0B3D59");
    private static final Color GOLD_COLOR   = Color.decode("#C5A059");
    private static final Color GREEN_COLOR  = Color.decode("#27AE60");
    private static final Color RED_COLOR    = Color.decode("#E74C3C");
    private static final Color SELECT_BG    = Color.decode("#EBF5FB");

    private final SimpleDateFormat dateSdf = new SimpleDateFormat("dd/MM/yyyy");

    // ════════════════════════════════════════════════════════════════════════
    //  CONSTRUCTOR
    // ════════════════════════════════════════════════════════════════════════

    public QuanLyCaLam() {
        setLayout(new BorderLayout(0, 10));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(14, 18, 14, 18));

        JLabel lblTitle = new JLabel("QUẢN LÝ CA LÀM VIỆC", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Inter Bold", Font.BOLD, 28));
        lblTitle.setForeground(TEXT_DARK);
        add(lblTitle, BorderLayout.NORTH);

        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(new Font("Inter Bold", Font.BOLD, 14));
        tabs.addTab("📋  Danh Sách Ca", createCaLamTab());
        tabs.addTab("📅  Lịch Làm Việc", createLichLamViecTab());
        add(tabs, BorderLayout.CENTER);

        loadDataAsync();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  TAB 1: CA LÀM
    // ════════════════════════════════════════════════════════════════════════

    private JPanel createCaLamTab() {
        JPanel p = new JPanel(new BorderLayout(10, 0));
        p.setBackground(Color.WHITE);
        p.setBorder(new EmptyBorder(10, 0, 0, 0));

        // Bảng danh sách
        String[] cols = {"Mã Ca", "Tên Ca", "Giờ Bắt Đầu", "Giờ Kết Thúc", "Trạng Thái"};
        modelCaLam = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tableCaLam = new JTable(modelCaLam);
        styleTable(tableCaLam);
        tableCaLam.getColumnModel().getColumn(0).setPreferredWidth(70);
        tableCaLam.getColumnModel().getColumn(1).setPreferredWidth(120);
        tableCaLam.getColumnModel().getColumn(2).setPreferredWidth(100);
        tableCaLam.getColumnModel().getColumn(3).setPreferredWidth(100);
        tableCaLam.getColumnModel().getColumn(4).setPreferredWidth(100);

        JScrollPane scroll = new JScrollPane(tableCaLam);
        scroll.setBorder(titledBorder("DANH SÁCH CA"));
        p.add(scroll, BorderLayout.CENTER);

        // Form bên phải
        p.add(createCaLamFormPanel(), BorderLayout.EAST);

        // Selection listener → fill form
        tableCaLam.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) fillCaLamForm();
        });

        return p;
    }

    private JPanel createCaLamFormPanel() {
        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Color.WHITE);
        form.setPreferredSize(new Dimension(280, 0));
        form.setBorder(titledBorder("THÔNG TIN CA"));

        GridBagConstraints g = new GridBagConstraints();
        g.insets  = new Insets(8, 8, 8, 8);
        g.fill    = GridBagConstraints.HORIZONTAL;
        g.weightx = 1;

        txtMaCa      = mkField(200);
        txtTenCa     = mkField(200);
        txtGioBatDau = mkField(200); txtGioBatDau.setToolTipText("Định dạng HH:mm, ví dụ 06:00");
        txtGioKetThuc = mkField(200); txtGioKetThuc.setToolTipText("Định dạng HH:mm, ví dụ 14:00");
        chkTrangThai  = new JCheckBox("Đang hoạt động"); chkTrangThai.setSelected(true);
        chkTrangThai.setBackground(Color.WHITE);
        chkTrangThai.setFont(new Font("Inter", Font.PLAIN, 13));

        int row = 0;
        addFormRow(form, g, row++, "Mã Ca:", txtMaCa);
        addFormRow(form, g, row++, "Tên Ca:", txtTenCa);
        addFormRow(form, g, row++, "Giờ Bắt Đầu:", txtGioBatDau);
        addFormRow(form, g, row++, "Giờ Kết Thúc:", txtGioKetThuc);
        g.gridy = row++; g.gridx = 0; g.gridwidth = 2; form.add(chkTrangThai, g); g.gridwidth = 1;

        // Buttons
        btnThemCa  = mkBtn("THÊM",    GREEN_COLOR, Color.WHITE, 120);
        btnSuaCa   = mkBtn("SỬA",     GOLD_COLOR,  MAIN_BLUE,  120);
        btnXoaCa   = mkBtn("XÓA",     RED_COLOR,   Color.WHITE, 120);
        btnLamMoiCa = mkBtn("LÀM MỚI", Color.WHITE, TEXT_DARK,  120);
        btnLamMoiCa.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));

        JPanel btnPanel = new JPanel(new GridLayout(2, 2, 6, 6));
        btnPanel.setBackground(Color.WHITE);
        btnPanel.add(btnThemCa); btnPanel.add(btnSuaCa);
        btnPanel.add(btnXoaCa); btnPanel.add(btnLamMoiCa);

        g.gridy = row; g.gridx = 0; g.gridwidth = 2; form.add(btnPanel, g);

        // Events
        btnThemCa.addActionListener(e -> handleThemCa());
        btnSuaCa.addActionListener(e -> handleSuaCa());
        btnXoaCa.addActionListener(e -> handleXoaCa());
        btnLamMoiCa.addActionListener(e -> clearCaLamForm());

        return form;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  TAB 2: LỊCH LÀM VIỆC
    // ════════════════════════════════════════════════════════════════════════

    private JPanel createLichLamViecTab() {
        JPanel p = new JPanel(new BorderLayout(0, 10));
        p.setBackground(Color.WHITE);
        p.setBorder(new EmptyBorder(10, 0, 0, 0));

        p.add(createLichFilterPanel(), BorderLayout.NORTH);

        String[] cols = {"Mã Lịch", "Nhân Viên", "Ca Làm", "Ngày Làm", "Ghi Chú"};
        modelLich = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tableLich = new JTable(modelLich);
        styleTable(tableLich);
        JScrollPane scroll = new JScrollPane(tableLich);
        scroll.setBorder(titledBorder("DANH SÁCH LỊCH LÀM VIỆC"));
        p.add(scroll, BorderLayout.CENTER);
        p.add(createLichFormPanel(), BorderLayout.SOUTH);
        return p;
    }

    private JPanel createLichFilterPanel() {
        JPanel fp = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 8));
        fp.setBackground(Color.WHITE);
        fp.setBorder(titledBorder("LỌC LỊCH"));

        fp.add(mkLabel("Ca:"));
        cmbLocCa = mkCombo(150); cmbLocCa.addItem("Tất cả"); fp.add(cmbLocCa);
        fp.add(mkLabel("Ngày:"));
        txtLocNgay = mkField(110); txtLocNgay.setToolTipText("dd/MM/yyyy"); fp.add(txtLocNgay);
        btnLocLich = mkBtn("LỌC", MAIN_BLUE, Color.WHITE, 90); fp.add(btnLocLich);

        btnLocLich.addActionListener(e -> loadLichData());
        return fp;
    }

    private JPanel createLichFormPanel() {
        JPanel form = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 8));
        form.setBackground(Color.WHITE);
        form.setBorder(titledBorder("THÊM LỊCH LÀM VIỆC"));

        cmbNhanVienLich = mkCombo(180);
        cmbCaLich       = mkCombo(160);
        txtNgayLam      = mkField(110); txtNgayLam.setText(dateSdf.format(new Date()));
        txtNgayLam.setToolTipText("dd/MM/yyyy");
        txtGhiChu       = mkField(200);

        form.add(mkLabel("Nhân Viên:")); form.add(cmbNhanVienLich);
        form.add(mkLabel("Ca:"));        form.add(cmbCaLich);
        form.add(mkLabel("Ngày Làm:")); form.add(txtNgayLam);
        form.add(mkLabel("Ghi Chú:"));  form.add(txtGhiChu);

        btnThemLich  = mkBtn("THÊM", GREEN_COLOR, Color.WHITE, 100);
        btnXoaLich   = mkBtn("XÓA",  RED_COLOR,   Color.WHITE, 100);
        btnLamMoiLich = mkBtn("LÀM MỚI", Color.WHITE, TEXT_DARK, 100);
        btnLamMoiLich.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));

        form.add(btnThemLich); form.add(btnXoaLich); form.add(btnLamMoiLich);

        btnThemLich.addActionListener(e -> handleThemLich());
        btnXoaLich.addActionListener(e -> handleXoaLich());
        btnLamMoiLich.addActionListener(e -> clearLichForm());

        return form;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  DATA LOADING
    // ════════════════════════════════════════════════════════════════════════

    private void loadDataAsync() {
        new SwingWorker<Object[], Void>() {
            @Override protected Object[] doInBackground() {
                return new Object[]{ caDao.getAllCaLam(), nvDao.getAllNhanVien() };
            }
            @Override @SuppressWarnings("unchecked") protected void done() {
                try {
                    Object[] r = get();
                    dsCaLam   = (List<CaLam>)    r[0];
                    dsNhanVien = (List<NhanVien>) r[1];
                    populateCaLamTable();
                    populateCombos();
                    loadLichData();
                } catch (Exception e) { e.printStackTrace(); }
            }
        }.execute();
    }

    private void populateCaLamTable() {
        modelCaLam.setRowCount(0);
        for (CaLam ca : dsCaLam) {
            String bd = ca.getGioBatDau()  != null ? ca.getGioBatDau().toString().substring(0,5)  : "";
            String kt = ca.getGioKetThuc() != null ? ca.getGioKetThuc().toString().substring(0,5) : "";
            modelCaLam.addRow(new Object[]{
                ca.getMaCa(), ca.getTenCa(), bd, kt,
                ca.isTrangThai() ? "Hoạt động" : "Ngừng"
            });
        }
    }

    private void populateCombos() {
        // ComboBox Ca cho form thêm lịch
        cmbCaLich.removeAllItems();
        cmbLocCa.removeAllItems(); cmbLocCa.addItem("Tất cả");
        for (CaLam ca : dsCaLam) {
            cmbCaLich.addItem(ca.getDisplayName());
            cmbLocCa.addItem(ca.getDisplayName());
        }
        // ComboBox NhanVien
        cmbNhanVienLich.removeAllItems();
        for (NhanVien nv : dsNhanVien) {
            cmbNhanVienLich.addItem(nv.getMaNV() + " - " + nv.getTenNV());
        }
    }

    private void loadLichData() {
        modelLich.setRowCount(0);
        new SwingWorker<List<LichLamViec>, Void>() {
            @Override protected List<LichLamViec> doInBackground() {
                // Lọc theo ca + ngày nếu có
                String selCa   = (String) cmbLocCa.getSelectedItem();
                String selNgay = txtLocNgay.getText().trim();

                if ((selCa == null || selCa.equals("Tất cả")) && selNgay.isEmpty())
                    return lichDao.getAll();

                // Tìm ca
                CaLam ca = null;
                if (selCa != null && !selCa.equals("Tất cả")) {
                    for (CaLam c : dsCaLam) if (c.getDisplayName().equals(selCa)) { ca = c; break; }
                }
                Date ngay = null;
                if (!selNgay.isEmpty()) {
                    try { ngay = new SimpleDateFormat("dd/MM/yyyy").parse(selNgay); } catch (Exception ignored) {}
                }

                if (ca != null && ngay != null)
                    return lichDao.getByCaAndDate(ca.getMaCa(), ngay);
                if (ca != null)
                    // Lấy tất cả lịch của ca (dùng getAll rồi filter)
                    return filterByCa(lichDao.getAll(), ca.getMaCa());
                return lichDao.getAll();
            }
            @Override protected void done() {
                try {
                    List<LichLamViec> ds = get();
                    for (LichLamViec l : ds) {
                        String nvTen = l.getNhanVien() != null
                                ? l.getNhanVien().getMaNV() + " - " + l.getNhanVien().getTenNV() : "";
                        String caTen = l.getCaLam() != null ? l.getCaLam().getDisplayName() : "";
                        String ngay  = l.getNgayLam() != null ? dateSdf.format(l.getNgayLam()) : "";
                        modelLich.addRow(new Object[]{
                            l.getMaLich(), nvTen, caTen, ngay, l.getGhiChu()
                        });
                    }
                } catch (Exception e) { e.printStackTrace(); }
            }
        }.execute();
    }

    private List<LichLamViec> filterByCa(List<LichLamViec> ds, String maCa) {
        List<LichLamViec> r = new ArrayList<>();
        for (LichLamViec l : ds)
            if (l.getCaLam() != null && maCa.equals(l.getCaLam().getMaCa())) r.add(l);
        return r;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  ACTION HANDLERS – CA LÀM
    // ════════════════════════════════════════════════════════════════════════

    private void handleThemCa() {
        CaLam ca = buildCaLamFromForm();
        if (ca == null) return;
        if (caDao.getCaLamByMa(ca.getMaCa()) != null) {
            JOptionPane.showMessageDialog(this, "Mã ca đã tồn tại!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (caDao.create(ca)) {
            JOptionPane.showMessageDialog(this, "Thêm ca thành công!");
            dsCaLam.add(ca); populateCaLamTable(); populateCombos(); clearCaLamForm();
        } else {
            JOptionPane.showMessageDialog(this, "Lỗi thêm ca!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleSuaCa() {
        int row = tableCaLam.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Chọn ca cần sửa!"); return; }
        CaLam ca = buildCaLamFromForm();
        if (ca == null) return;
        if (caDao.update(ca)) {
            JOptionPane.showMessageDialog(this, "Cập nhật ca thành công!");
            // Cập nhật cache
            for (int i = 0; i < dsCaLam.size(); i++) {
                if (dsCaLam.get(i).getMaCa().equals(ca.getMaCa())) { dsCaLam.set(i, ca); break; }
            }
            populateCaLamTable(); populateCombos();
        }
    }

    private void handleXoaCa() {
        int row = tableCaLam.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Chọn ca cần xóa!"); return; }
        String maCa = modelCaLam.getValueAt(row, 0).toString();
        int confirm = JOptionPane.showConfirmDialog(this,
                "Xóa ca " + maCa + "? (Các hóa đơn thuộc ca này sẽ bị gỡ liên kết)",
                "Xác nhận xóa", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (caDao.delete(maCa)) {
                JOptionPane.showMessageDialog(this, "Đã xóa ca " + maCa);
                dsCaLam.removeIf(c -> c.getMaCa().equals(maCa));
                populateCaLamTable(); populateCombos(); clearCaLamForm();
            }
        }
    }

    private CaLam buildCaLamFromForm() {
        String maCa  = txtMaCa.getText().trim();
        String tenCa = txtTenCa.getText().trim();
        String gbd   = txtGioBatDau.getText().trim();
        String gkt   = txtGioKetThuc.getText().trim();

        if (maCa.isEmpty() || tenCa.isEmpty() || gbd.isEmpty() || gkt.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ thông tin!", "Lỗi", JOptionPane.WARNING_MESSAGE);
            return null;
        }
        try {
            Time bd = Time.valueOf(gbd.length() == 5 ? gbd + ":00" : gbd);
            Time kt = Time.valueOf(gkt.length() == 5 ? gkt + ":00" : gkt);
            return new CaLam(maCa, tenCa, bd, kt, chkTrangThai.isSelected());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Giờ không hợp lệ! Định dạng HH:mm", "Lỗi", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }

    private void fillCaLamForm() {
        int row = tableCaLam.getSelectedRow();
        if (row == -1) return;
        txtMaCa.setText(modelCaLam.getValueAt(row, 0).toString());
        txtTenCa.setText(modelCaLam.getValueAt(row, 1).toString());
        txtGioBatDau.setText(modelCaLam.getValueAt(row, 2).toString());
        txtGioKetThuc.setText(modelCaLam.getValueAt(row, 3).toString());
        chkTrangThai.setSelected("Hoạt động".equals(modelCaLam.getValueAt(row, 4).toString()));
    }

    private void clearCaLamForm() {
        txtMaCa.setText(caDao.getNextMaCa());
        txtTenCa.setText("");
        txtGioBatDau.setText("");
        txtGioKetThuc.setText("");
        chkTrangThai.setSelected(true);
        tableCaLam.clearSelection();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  ACTION HANDLERS – LỊCH LÀM VIỆC
    // ════════════════════════════════════════════════════════════════════════

    private void handleThemLich() {
        int nvIdx = cmbNhanVienLich.getSelectedIndex();
        int caIdx = cmbCaLich.getSelectedIndex();
        if (nvIdx < 0 || caIdx < 0 || nvIdx >= dsNhanVien.size() || caIdx >= dsCaLam.size()) {
            JOptionPane.showMessageDialog(this, "Chọn nhân viên và ca làm!", "Lỗi", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String ngayStr = txtNgayLam.getText().trim();
        Date ngay;
        try { ngay = dateSdf.parse(ngayStr); }
        catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Ngày không hợp lệ! Định dạng dd/MM/yyyy", "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }

        LichLamViec l = new LichLamViec(0, dsNhanVien.get(nvIdx), dsCaLam.get(caIdx),
                ngay, txtGhiChu.getText().trim());

        if (lichDao.create(l)) {
            JOptionPane.showMessageDialog(this, "Thêm lịch thành công!");
            loadLichData(); clearLichForm();
        } else {
            JOptionPane.showMessageDialog(this,
                    "Lỗi! Nhân viên này có thể đã có lịch trong ca + ngày này.", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleXoaLich() {
        int row = tableLich.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Chọn lịch cần xóa!"); return; }
        int maLich = (int) modelLich.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this,
                "Xóa lịch làm việc #" + maLich + "?", "Xác nhận", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (lichDao.delete(maLich)) { JOptionPane.showMessageDialog(this, "Đã xóa!"); loadLichData(); }
        }
    }

    private void clearLichForm() {
        if (!dsNhanVien.isEmpty()) cmbNhanVienLich.setSelectedIndex(0);
        if (!dsCaLam.isEmpty())   cmbCaLich.setSelectedIndex(0);
        txtNgayLam.setText(dateSdf.format(new Date()));
        txtGhiChu.setText("");
    }

    // ════════════════════════════════════════════════════════════════════════
    //  UI HELPERS
    // ════════════════════════════════════════════════════════════════════════

    private TitledBorder titledBorder(String title) {
        TitledBorder b = BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(BORDER_COLOR), title);
        b.setTitleFont(new Font("Inter Bold", Font.BOLD, 13));
        b.setTitleColor(TEXT_DARK);
        return b;
    }

    private void addFormRow(JPanel p, GridBagConstraints g, int row, String label, JComponent comp) {
        g.gridy = row; g.gridx = 0; g.weightx = 0; p.add(mkLabel(label), g);
        g.gridx = 1; g.weightx = 1; p.add(comp, g);
    }

    private JLabel mkLabel(String t) {
        JLabel l = new JLabel(t);
        l.setFont(new Font("Inter Bold", Font.BOLD, 13));
        l.setForeground(TEXT_DARK);
        return l;
    }
    private JTextField mkField(int w) {
        JTextField f = new JTextField();
        f.setFont(new Font("Inter", Font.PLAIN, 13));
        f.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));
        f.setPreferredSize(new Dimension(w, 38));
        return f;
    }
    private JComboBox<String> mkCombo(int w) {
        JComboBox<String> c = new JComboBox<>();
        c.setFont(new Font("Inter", Font.PLAIN, 13));
        c.setPreferredSize(new Dimension(w, 38));
        c.setBackground(Color.WHITE);
        return c;
    }
    private JButton mkBtn(String t, Color bg, Color fg, int w) {
        JButton b = new JButton(t);
        b.setFont(new Font("Inter Bold", Font.BOLD, 13));
        b.setBackground(bg); b.setForeground(fg);
        b.setFocusPainted(false);
        b.setPreferredSize(new Dimension(w, 40));
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return b;
    }
    private void styleTable(JTable t) {
        t.setFont(new Font("Inter", Font.PLAIN, 13));
        t.setRowHeight(34);
        t.setSelectionBackground(SELECT_BG);
        t.setSelectionForeground(TEXT_DARK);
        t.getTableHeader().setFont(new Font("Inter Bold", Font.BOLD, 13));
        t.getTableHeader().setPreferredSize(new Dimension(0, 36));
        t.setGridColor(new Color(235, 235, 235));
        t.setBackground(Color.WHITE);
        t.setShowVerticalLines(false);
    }
}
