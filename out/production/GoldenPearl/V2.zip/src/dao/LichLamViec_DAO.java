package dao;

import connectDB.ConnectDB;
import entity.CaLam;
import entity.CaLamTheoNgay;
import entity.DangKyCa;
import entity.LichLamViec;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;

public class LichLamViec_DAO {

    // ── READ ──────────────────────────────────────────────────────────────

    public List<LichLamViec> getAll() {
        String sql = buildSelectJoin() + " ORDER BY cn.ngayLam DESC, c.gioBatDau";
        return query(sql);
    }

    public List<LichLamViec> getByNhanVien(String maNhanVien) {
        String sql = buildSelectJoin()
                + " WHERE l.maNhanVien = ?"
                + " ORDER BY cn.ngayLam DESC, c.gioBatDau";
        return queryWith(sql, maNhanVien);
    }

    public List<LichLamViec> getByCaNgay(int idCaNgay) {
        String sql = buildSelectJoin()
                + " WHERE l.idCaNgay = ?"
                + " ORDER BY nv.tenNV";
        List<LichLamViec> ds = new ArrayList<>();
        try (Connection con = ConnectDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idCaNgay);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) ds.add(mapFull(rs));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return ds;
    }

    public List<LichLamViec> getByNgay(java.sql.Date ngay) {
        String sql = buildSelectJoin()
                + " WHERE cn.ngayLam = ?"
                + " ORDER BY c.gioBatDau, nv.tenNV";
        List<LichLamViec> ds = new ArrayList<>();
        try (Connection con = ConnectDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setDate(1, ngay);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) ds.add(mapFull(rs));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return ds;
    }

    public List<LichLamViec> getByKhoangNgay(java.sql.Date tuNgay, java.sql.Date denNgay) {
        String sql = buildSelectJoin()
                + " WHERE cn.ngayLam BETWEEN ? AND ?"
                + " ORDER BY cn.ngayLam, c.gioBatDau, nv.tenNV";
        List<LichLamViec> ds = new ArrayList<>();
        try (Connection con = ConnectDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setDate(1, tuNgay);
            ps.setDate(2, denNgay);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) ds.add(mapFull(rs));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return ds;
    }

    public LinkedHashMap<CaLamTheoNgay, List<LichLamViec>> getLichTheoNgayNhomTheoCa(java.sql.Date ngay) {
        LinkedHashMap<CaLamTheoNgay, List<LichLamViec>> result = new LinkedHashMap<>();

        CaLamTheoNgay_DAO caNgayDao = new CaLamTheoNgay_DAO();
        List<CaLamTheoNgay> dsCaNgay = caNgayDao.getByNgay(ngay);

        for (CaLamTheoNgay cn : dsCaNgay) {
            result.put(cn, new ArrayList<>());
        }

        List<LichLamViec> dsLich = getByNgay(ngay);
        for (LichLamViec l : dsLich) {
            for (CaLamTheoNgay cn : result.keySet()) {
                if (cn.getIdCaNgay() == l.getIdCaNgay()) {
                    result.get(cn).add(l);
                    break;
                }
            }
        }
        return result;
    }

    // ── CREATE ────────────────────────────────────────────────────────────

    public int create(LichLamViec l) {
        if (l.getTrangThai() == null) l.setTrangThai(LichLamViec.TT_LAM_VIEC);
        String sql = "INSERT INTO LichLamViec (idCaNgay, maNhanVien, trangThai, ghiChu) "
                + "VALUES (?, ?, ?, ?)";
        try (Connection con = ConnectDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, l.getIdCaNgay());
            ps.setString(2, l.getMaNhanVien());
            ps.setString(3, l.getTrangThai());
            ps.setString(4, l.getGhiChu() != null ? l.getGhiChu() : "");
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) return keys.getInt(1);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return -1;
    }

    // ── UPDATE ────────────────────────────────────────────────────────────

    public boolean updateTrangThai(int idLich, String trangThai, String ghiChu) {
        String sql = "UPDATE LichLamViec SET trangThai = ?, ghiChu = ? WHERE idLich = ?";
        try (Connection con = ConnectDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, trangThai);
            ps.setString(2, ghiChu != null ? ghiChu : "");
            ps.setInt(3, idLich);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public boolean doiCa(int idLich, int idCaNgayMoi, String ghiChu) {
        String sql = "UPDATE LichLamViec SET idCaNgay = ?, trangThai = N'Đổi ca', ghiChu = ? WHERE idLich = ?";
        try (Connection con = ConnectDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idCaNgayMoi);
            ps.setString(2, ghiChu != null ? ghiChu : "");
            ps.setInt(3, idLich);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    // ── DELETE ────────────────────────────────────────────────────────────

    public boolean delete(int idLich) {
        String sql = "DELETE FROM LichLamViec WHERE idLich = ?";
        try (Connection con = ConnectDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idLich);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    // ── GENERATE ──────────────────────────────────────────────────────────

    public int generateFromDangKy(DangKyCa dk) {
        if (dk == null || dk.getNgayBatDau() == null || dk.getNgayKetThuc() == null) return 0;

        int count = 0;
        String sqlFind = "SELECT idCaNgay FROM CaLamTheoNgay WHERE ngayLam = ? AND maCa = ?";
        String sqlInsert = "IF NOT EXISTS ("
                + "  SELECT 1 FROM LichLamViec WHERE idCaNgay = ? AND maNhanVien = ?"
                + ") "
                + "INSERT INTO LichLamViec (idCaNgay, maNhanVien, trangThai, ghiChu) "
                + "VALUES (?, ?, N'Làm việc', N'')";

        try (Connection con = ConnectDB.getConnection();
             PreparedStatement pFind = con.prepareStatement(sqlFind);
             PreparedStatement pIns  = con.prepareStatement(sqlInsert)) {

            Calendar cur = Calendar.getInstance();
            cur.setTime(dk.getNgayBatDau());
            cur.set(Calendar.HOUR_OF_DAY, 0); cur.set(Calendar.MINUTE, 0);
            cur.set(Calendar.SECOND, 0);      cur.set(Calendar.MILLISECOND, 0);

            Calendar end = Calendar.getInstance();
            end.setTime(dk.getNgayKetThuc());
            end.set(Calendar.HOUR_OF_DAY, 23);

            while (!cur.after(end)) {
                if (dk.includesDate(cur.getTime())) {
                    java.sql.Date sqlDate = new java.sql.Date(cur.getTimeInMillis());
                    pFind.setDate(1, sqlDate);
                    pFind.setString(2, dk.getMaCa());
                    try (ResultSet rs = pFind.executeQuery()) {
                        if (rs.next()) {
                            int idCaNgay = rs.getInt("idCaNgay");
                            pIns.setInt(1, idCaNgay);
                            pIns.setString(2, dk.getMaNhanVien());
                            pIns.setInt(3, idCaNgay);
                            pIns.setString(4, dk.getMaNhanVien());
                            pIns.executeUpdate();
                            count++;
                        }
                    }
                }
                cur.add(Calendar.DAY_OF_MONTH, 1);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return count;
    }

    // ── DDL ───────────────────────────────────────────────────────────────

    public static String getMigrationSQL() {
        return "IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'LichLamViec') "
                + "CREATE TABLE LichLamViec ("
                + "  idLich       INT           IDENTITY(1,1) PRIMARY KEY,"
                + "  idCaNgay     INT           NOT NULL REFERENCES CaLamTheoNgay(idCaNgay),"
                + "  maNhanVien   VARCHAR(20)   NOT NULL REFERENCES NhanVien(maNV),"
                + "  trangThai    NVARCHAR(30)  NOT NULL DEFAULT N'Làm việc',"
                + "  ghiChu       NVARCHAR(255) NULL,"
                + "  CONSTRAINT UQ_LichLamViec UNIQUE (idCaNgay, maNhanVien)"
                + ");";
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private String buildSelectJoin() {
        return "SELECT l.idLich, l.idCaNgay, l.maNhanVien, l.trangThai, l.ghiChu, "
                + "       nv.tenNV, "
                + "       cn.ngayLam, cn.maCa, cn.trangThai AS trangThaiCa, "
                + "       c.tenCa, c.gioBatDau, c.gioKetThuc "
                + "FROM LichLamViec l "
                + "JOIN NhanVien nv        ON l.maNhanVien = nv.maNV "
                + "JOIN CaLamTheoNgay cn   ON l.idCaNgay   = cn.idCaNgay "
                + "JOIN CaLam c            ON cn.maCa       = c.maCa";
    }

    private List<LichLamViec> query(String sql) {
        List<LichLamViec> ds = new ArrayList<>();
        try (Connection con = ConnectDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) ds.add(mapFull(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return ds;
    }

    private List<LichLamViec> queryWith(String sql, Object param) {
        List<LichLamViec> ds = new ArrayList<>();
        try (Connection con = ConnectDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setObject(1, param);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) ds.add(mapFull(rs));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return ds;
    }

    private LichLamViec mapFull(ResultSet rs) throws SQLException {
        LichLamViec l = new LichLamViec();
        l.setIdLich(rs.getInt("idLich"));
        l.setIdCaNgay(rs.getInt("idCaNgay"));
        l.setMaNhanVien(rs.getString("maNhanVien"));
        l.setTrangThai(rs.getString("trangThai"));
        try { l.setGhiChu(rs.getString("ghiChu")); } catch (Exception ignored) {}
        try { l.setTenNhanVien(rs.getString("tenNV")); } catch (Exception ignored) {}

        try {
            CaLamTheoNgay cn = new CaLamTheoNgay();
            cn.setIdCaNgay(rs.getInt("idCaNgay"));
            cn.setNgayLam(rs.getDate("ngayLam"));
            cn.setMaCa(rs.getString("maCa"));
            cn.setTrangThai(rs.getString("trangThaiCa"));

            CaLam ca = new CaLam();
            ca.setMaCa(rs.getString("maCa"));
            ca.setTenCa(rs.getString("tenCa"));
            ca.setGioBatDau(rs.getTime("gioBatDau"));
            ca.setGioKetThuc(rs.getTime("gioKetThuc"));
            cn.setCaLam(ca);

            l.setCaNgay(cn);
        } catch (Exception ignored) {}

        return l;
    }
}