package dao;

import connectDB.ConnectDB;
import entity.CaLam;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO cho {@link CaLam}.
 *
 * <p><b>Thiết kế quan trọng:</b> CaLam chỉ có 3 ca cố định, được tạo sẵn
 * bởi {@link #getSeedSQL()}. KHÔNG có create/delete động.
 * Chỉ hỗ trợ đọc và cập nhật giờ ca (admin only).
 */
public class CaLam_DAO {

    // ── READ ──────────────────────────────────────────────────────────────

    /** Lấy tất cả ca, sắp xếp theo giờ bắt đầu. */
    public List<CaLam> getAll() {
        List<CaLam> ds = new ArrayList<>();
        try (Connection con = ConnectDB.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM CaLam ORDER BY gioBatDau")) {
            while (rs.next()) ds.add(map(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return ds;
    }

    public CaLam getByMa(String maCa) {
        String sql = "SELECT * FROM CaLam WHERE maCa = ?";
        try (Connection con = ConnectDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, maCa);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    // ── UPDATE (admin only – chỉ sửa tên và giờ) ─────────────────────────

    /**
     * Cập nhật giờ và tên ca. KHÔNG cho phép đổi maCa.
     */
    public boolean update(CaLam ca) {
        String sql = "UPDATE CaLam SET tenCa = ?, gioBatDau = ?, gioKetThuc = ? WHERE maCa = ?";
        try (Connection con = ConnectDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setNString(1, ca.getTenCa());
            ps.setTime(2, ca.getGioBatDau());
            ps.setTime(3, ca.getGioKetThuc());
            ps.setString(4, ca.getMaCa());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    // ── DDL / Seed ────────────────────────────────────────────────────────

    /**
     * DDL tạo bảng CaLam.
     * CaLam là danh mục cố định: KHÔNG có cột trangThai.
     */
    public static String getMigrationSQL() {
        return "IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'CaLam') "
                + "CREATE TABLE CaLam ("
                + "  maCa        VARCHAR(10)   NOT NULL PRIMARY KEY,"
                + "  tenCa       NVARCHAR(50)  NOT NULL,"
                + "  gioBatDau   TIME          NOT NULL,"
                + "  gioKetThuc  TIME          NOT NULL"
                + ");";
    }

    /**
     * Seed 3 ca mặc định.
     * Chỉ insert nếu bảng rỗng – tránh trùng lặp khi chạy lại.
     */
    public static String getSeedSQL() {
        return "IF NOT EXISTS (SELECT 1 FROM CaLam) "
                + "INSERT INTO CaLam (maCa, tenCa, gioBatDau, gioKetThuc) VALUES "
                + "('C1', N'Ca sáng',  '06:00', '14:00'),"
                + "('C2', N'Ca chiều', '14:00', '22:00'),"
                + "('C3', N'Ca tối',   '22:00', '06:00');";
    }

    // ── Mapper ────────────────────────────────────────────────────────────

    private CaLam map(ResultSet rs) throws SQLException {
        CaLam ca = new CaLam();
        ca.setMaCa(rs.getString("maCa"));
        ca.setTenCa(rs.getNString("tenCa"));
        ca.setGioBatDau(rs.getTime("gioBatDau"));
        ca.setGioKetThuc(rs.getTime("gioKetThuc"));
        return ca;
    }
}
