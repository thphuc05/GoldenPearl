package dao;

import connectDB.ConnectDB;
import entity.CaLam;
import entity.CaLamTheoNgay;
import entity.DangKyCa;

import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * DAO cho {@link CaLamTheoNgay}.
 *
 * <p>Quản lý ca làm thực tế theo từng ngày.
 * Unique constraint DB: (ngayLam, maCa) – mỗi ngày chỉ có 1 record mỗi ca.
 *
 * <p><b>Flow generate:</b><br>
 * Khi có DangKyCa được duyệt → gọi {@link #generateFromDangKy} để
 * sinh record CaLamTheoNgay cho từng ngày trong khoảng đăng ký.
 */
public class CaLamTheoNgay_DAO {

    // ── READ ──────────────────────────────────────────────────────────────

    /** Lấy tất cả ca theo ngày, sắp xếp mới nhất trước. */
    public List<CaLamTheoNgay> getAll() {
        List<CaLamTheoNgay> ds = new ArrayList<>();
        String sql = "SELECT cn.*, c.tenCa, c.gioBatDau, c.gioKetThuc "
                + "FROM CaLamTheoNgay cn "
                + "JOIN CaLam c ON cn.maCa = c.maCa "
                + "ORDER BY cn.ngayLam DESC, c.gioBatDau";
        try (Connection con = ConnectDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) ds.add(mapFull(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return ds;
    }

    /**
     * Lấy danh sách ca trong một ngày cụ thể, sắp theo giờ bắt đầu.
     */
    public List<CaLamTheoNgay> getByNgay(Date ngay) {
        List<CaLamTheoNgay> ds = new ArrayList<>();
        String sql = "SELECT cn.*, c.tenCa, c.gioBatDau, c.gioKetThuc "
                + "FROM CaLamTheoNgay cn "
                + "JOIN CaLam c ON cn.maCa = c.maCa "
                + "WHERE cn.ngayLam = ? "
                + "ORDER BY c.gioBatDau";
        try (Connection con = ConnectDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setDate(1, ngay);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) ds.add(mapFull(rs));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return ds;
    }

    /** Lấy record cụ thể theo ngày + maCa. */
    public CaLamTheoNgay getByNgayVaCa(Date ngay, String maCa) {
        String sql = "SELECT cn.*, c.tenCa, c.gioBatDau, c.gioKetThuc "
                + "FROM CaLamTheoNgay cn "
                + "JOIN CaLam c ON cn.maCa = c.maCa "
                + "WHERE cn.ngayLam = ? AND cn.maCa = ?";
        try (Connection con = ConnectDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setDate(1, ngay);
            ps.setString(2, maCa);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapFull(rs);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    public CaLamTheoNgay getById(int idCaNgay) {
        String sql = "SELECT cn.*, c.tenCa, c.gioBatDau, c.gioKetThuc "
                + "FROM CaLamTheoNgay cn "
                + "JOIN CaLam c ON cn.maCa = c.maCa "
                + "WHERE cn.idCaNgay = ?";
        try (Connection con = ConnectDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idCaNgay);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapFull(rs);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    /** Lấy ca trong khoảng ngày (dùng cho lịch tuần). */
    public List<CaLamTheoNgay> getByKhoangNgay(Date tuNgay, Date denNgay) {
        List<CaLamTheoNgay> ds = new ArrayList<>();
        String sql = "SELECT cn.*, c.tenCa, c.gioBatDau, c.gioKetThuc "
                + "FROM CaLamTheoNgay cn "
                + "JOIN CaLam c ON cn.maCa = c.maCa "
                + "WHERE cn.ngayLam BETWEEN ? AND ? "
                + "ORDER BY cn.ngayLam, c.gioBatDau";
        try (Connection con = ConnectDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setDate(1, tuNgay);
            ps.setDate(2, denNgay);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) ds.add(mapFull(rs));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return ds;
    }

    // ── UPDATE TRẠNG THÁI ─────────────────────────────────────────────────

    public boolean updateTrangThai(int idCaNgay, String trangThai) {
        String sql = "UPDATE CaLamTheoNgay SET trangThai = ? WHERE idCaNgay = ?";
        try (Connection con = ConnectDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setNString(1, trangThai);
            ps.setInt(2, idCaNgay);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    // ── GENERATE ──────────────────────────────────────────────────────────

    /**
     * Generate CaLamTheoNgay từ một DangKyCa đã được duyệt.
     *
     * @return số record được tạo mới
     */
    public int generateFromDangKy(DangKyCa dk) {
        if (dk == null || dk.getNgayBatDau() == null || dk.getNgayKetThuc() == null) return 0;

        int count = 0;
        String sql = "IF NOT EXISTS ("
                + "  SELECT 1 FROM CaLamTheoNgay WHERE ngayLam = ? AND maCa = ?"
                + ") "
                + "INSERT INTO CaLamTheoNgay (ngayLam, maCa, trangThai) "
                + "VALUES (?, ?, N'Chưa bắt đầu')";

        try (Connection con = ConnectDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            Calendar cur = Calendar.getInstance();
            cur.setTime(dk.getNgayBatDau());
            cur.set(Calendar.HOUR_OF_DAY, 0);
            cur.set(Calendar.MINUTE, 0);
            cur.set(Calendar.SECOND, 0);
            cur.set(Calendar.MILLISECOND, 0);

            Calendar end = Calendar.getInstance();
            end.setTime(dk.getNgayKetThuc());
            end.set(Calendar.HOUR_OF_DAY, 23);

            while (!cur.after(end)) {
                Date sqlDate = new Date(cur.getTimeInMillis());
                if (dk.includesDate(cur.getTime())) {
                    ps.setDate(1, sqlDate);
                    ps.setString(2, dk.getMaCa());
                    ps.setDate(3, sqlDate);
                    ps.setString(4, dk.getMaCa());
                    ps.executeUpdate();
                    count++;
                }
                cur.add(Calendar.DAY_OF_MONTH, 1);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return count;
    }

    /**
     * Generate CaLamTheoNgay cho TẤT CẢ 3 ca trong một ngày.
     * Dùng khi mở ngày mới thủ công (admin).
     *
     * @return số record được tạo mới
     */
    public int generateAllCaForNgay(Date ngay, List<CaLam> dsCaLam) {
        int count = 0;
        String sql = "IF NOT EXISTS ("
                + "  SELECT 1 FROM CaLamTheoNgay WHERE ngayLam = ? AND maCa = ?"
                + ") "
                + "INSERT INTO CaLamTheoNgay (ngayLam, maCa, trangThai) "
                + "VALUES (?, ?, N'Chưa bắt đầu')";
        try (Connection con = ConnectDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            for (CaLam ca : dsCaLam) {
                ps.setDate(1, ngay);
                ps.setString(2, ca.getMaCa());
                ps.setDate(3, ngay);
                ps.setString(4, ca.getMaCa());
                ps.executeUpdate();
                count++;
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return count;
    }

    // ── DDL ───────────────────────────────────────────────────────────────

    public static String getMigrationSQL() {
        return "IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'CaLamTheoNgay') "
                + "CREATE TABLE CaLamTheoNgay ("
                + "  idCaNgay   INT           IDENTITY(1,1) PRIMARY KEY,"
                + "  ngayLam    DATE          NOT NULL,"
                + "  maCa       VARCHAR(10)   NOT NULL REFERENCES CaLam(maCa),"
                + "  trangThai  NVARCHAR(30)  NOT NULL DEFAULT N'Chưa bắt đầu',"
                + "  CONSTRAINT UQ_CaLamTheoNgay UNIQUE (ngayLam, maCa)"
                + ");";
    }

    // ── Mapper ────────────────────────────────────────────────────────────

    private CaLamTheoNgay mapFull(ResultSet rs) throws SQLException {
        CaLamTheoNgay cn = new CaLamTheoNgay();
        cn.setIdCaNgay(rs.getInt("idCaNgay"));
        cn.setNgayLam(rs.getDate("ngayLam"));
        cn.setMaCa(rs.getString("maCa"));
        cn.setTrangThai(rs.getNString("trangThai"));

        try {
            CaLam ca = new CaLam();
            ca.setMaCa(rs.getString("maCa"));
            ca.setTenCa(rs.getNString("tenCa"));
            ca.setGioBatDau(rs.getTime("gioBatDau"));
            ca.setGioKetThuc(rs.getTime("gioKetThuc"));
            cn.setCaLam(ca);
        } catch (SQLException ignored) {}

        return cn;
    }
}