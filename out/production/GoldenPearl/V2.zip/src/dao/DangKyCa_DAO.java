package dao;

import connectDB.ConnectDB;
import entity.DangKyCa;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO cho {@link DangKyCa}.
 *
 * <p>Quản lý đăng ký ca theo khoảng thời gian của nhân viên.
 * Sau khi duyệt, gọi {@link CaLamTheoNgay_DAO#generateFromDangKy}
 * và {@link LichLamViec_DAO#generateFromDangKy} để sinh lịch thực tế.
 */
public class DangKyCa_DAO {

    // ── READ ──────────────────────────────────────────────────────────────

    public List<DangKyCa> getAll() {
        return query("SELECT dk.*, nv.tenNV FROM DangKyCa dk "
                + "LEFT JOIN NhanVien nv ON dk.maNhanVien = nv.maNV "
                + "ORDER BY dk.ngayBatDau DESC");
    }

    public List<DangKyCa> getByNhanVien(String maNhanVien) {
        List<DangKyCa> ds = new ArrayList<>();
        String sql = "SELECT * FROM DangKyCa WHERE maNhanVien = ? ORDER BY ngayBatDau DESC";
        try (Connection con = ConnectDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, maNhanVien);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) ds.add(map(rs));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return ds;
    }

    public List<DangKyCa> getByTrangThai(String trangThai) {
        List<DangKyCa> ds = new ArrayList<>();
        String sql = "SELECT * FROM DangKyCa WHERE trangThai = ? ORDER BY ngayBatDau DESC";
        try (Connection con = ConnectDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setNString(1, trangThai);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) ds.add(map(rs));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return ds;
    }

    /** Lấy các đăng ký đã duyệt, active trong khoảng ngày. */
    public List<DangKyCa> getDuyetTrongKhoang(Date tuNgay, Date denNgay) {
        List<DangKyCa> ds = new ArrayList<>();
        String sql = "SELECT * FROM DangKyCa "
                + "WHERE trangThai = N'Đã duyệt' "
                + "  AND ngayBatDau  <= ? "
                + "  AND ngayKetThuc >= ?";
        try (Connection con = ConnectDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setDate(1, denNgay);
            ps.setDate(2, tuNgay);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) ds.add(map(rs));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return ds;
    }

    public DangKyCa getById(int id) {
        String sql = "SELECT * FROM DangKyCa WHERE idDangKy = ?";
        try (Connection con = ConnectDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    // ── CREATE ────────────────────────────────────────────────────────────

    /**
     * Tạo đăng ký mới. maDangKy được sinh tự động theo quy tắc nghiệp vụ.
     * Trạng thái khởi tạo: "Chờ duyệt".
     *
     * @return idDangKy vừa insert, hoặc -1 nếu lỗi.
     */
    public int create(DangKyCa dk) {
        // Sinh maDangKy nghiệp vụ
        if (dk.getMaDangKy() == null || dk.getMaDangKy().isEmpty()) {
            dk.setMaDangKy(DangKyCa.buildMaDangKy(
                    dk.getMaCa(), dk.getMaNhanVien(), dk.getNgayBatDau()));
        }
        if (dk.getTrangThai() == null) dk.setTrangThai("Chờ duyệt");

        String sql = "INSERT INTO DangKyCa "
                + "(maDangKy, maNhanVien, maCa, ngayBatDau, ngayKetThuc, danhSachThu, trangThai) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = ConnectDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, dk.getMaDangKy());
            ps.setString(2, dk.getMaNhanVien());
            ps.setString(3, dk.getMaCa());
            ps.setDate(4, dk.getNgayBatDau());
            ps.setDate(5, dk.getNgayKetThuc());
            ps.setString(6, dk.getDanhSachThu());
            ps.setNString(7, dk.getTrangThai());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) return keys.getInt(1);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return -1;
    }

    // ── UPDATE ────────────────────────────────────────────────────────────

    public boolean updateTrangThai(int idDangKy, String trangThai) {
        String sql = "UPDATE DangKyCa SET trangThai = ? WHERE idDangKy = ?";
        try (Connection con = ConnectDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setNString(1, trangThai);
            ps.setInt(2, idDangKy);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public boolean update(DangKyCa dk) {
        String sql = "UPDATE DangKyCa SET maCa=?, ngayBatDau=?, ngayKetThuc=?, "
                + "danhSachThu=?, trangThai=? WHERE idDangKy=?";
        try (Connection con = ConnectDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, dk.getMaCa());
            ps.setDate(2, dk.getNgayBatDau());
            ps.setDate(3, dk.getNgayKetThuc());
            ps.setString(4, dk.getDanhSachThu());
            ps.setNString(5, dk.getTrangThai());
            ps.setInt(6, dk.getIdDangKy());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    // ── DELETE ────────────────────────────────────────────────────────────

    /** Chỉ cho xóa nếu trạng thái là "Chờ duyệt" hoặc "Từ chối". */
    public boolean delete(int idDangKy) {
        String sql = "DELETE FROM DangKyCa WHERE idDangKy = ? "
                + "AND trangThai IN (N'Chờ duyệt', N'Từ chối', N'Đã hủy')";
        try (Connection con = ConnectDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idDangKy);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    // ── DDL ───────────────────────────────────────────────────────────────

    public static String getMigrationSQL() {
        return "IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'DangKyCa') "
                + "CREATE TABLE DangKyCa ("
                + "  idDangKy     INT           IDENTITY(1,1) PRIMARY KEY,"
                + "  maDangKy     VARCHAR(50)   NOT NULL UNIQUE,"
                + "  maNhanVien   VARCHAR(20)   NOT NULL REFERENCES NhanVien(maNV),"
                + "  maCa         VARCHAR(10)   NOT NULL REFERENCES CaLam(maCa),"
                + "  ngayBatDau   DATE          NOT NULL,"
                + "  ngayKetThuc  DATE          NOT NULL,"
                + "  danhSachThu  VARCHAR(20)   NULL,"           // NULL = tất cả các ngày
                + "  trangThai    NVARCHAR(30)  NOT NULL DEFAULT N'Chờ duyệt',"
                + "  CONSTRAINT CK_DangKyCa_Ngay CHECK (ngayKetThuc >= ngayBatDau)"
                + ");";
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private List<DangKyCa> query(String sql, Object... params) {
        List<DangKyCa> ds = new ArrayList<>();
        try (Connection con = ConnectDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) ps.setObject(i + 1, params[i]);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) ds.add(map(rs));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return ds;
    }

    private DangKyCa map(ResultSet rs) throws SQLException {
        DangKyCa dk = new DangKyCa();
        dk.setIdDangKy(rs.getInt("idDangKy"));
        dk.setMaDangKy(rs.getString("maDangKy"));
        dk.setMaNhanVien(rs.getString("maNhanVien"));
        dk.setMaCa(rs.getString("maCa"));
        dk.setNgayBatDau(rs.getDate("ngayBatDau"));
        dk.setNgayKetThuc(rs.getDate("ngayKetThuc"));
        dk.setDanhSachThu(rs.getString("danhSachThu"));
        dk.setTrangThai(rs.getNString("trangThai"));
        return dk;
    }
}
