package entity;

/**
 * Entity lịch làm việc thực tế.
 *
 * <p>Lưu nhân viên nào thuộc ca thực tế nào ({@link CaLamTheoNgay}).
 * Được generate tự động từ {@link DangKyCa} đã duyệt,
 * hoặc được quản lý thêm/sửa thủ công.
 *
 * <p><b>Trạng thái hợp lệ:</b>
 * <ul>
 *   <li>Làm việc   – bình thường</li>
 *   <li>Nghỉ phép  – có xin phép</li>
 *   <li>Nghỉ không phép</li>
 *   <li>Đi trễ</li>
 *   <li>Tăng cường – hỗ trợ ca khác</li>
 *   <li>OT         – làm thêm giờ</li>
 *   <li>Đổi ca     – đã đổi sang ca/ngày khác</li>
 * </ul>
 */
public class LichLamViec {

    /** PK tự tăng */
    private int    idLich;

    /** FK → CaLamTheoNgay.idCaNgay */
    private int    idCaNgay;

    private String maNhanVien;
    private String trangThai;
    private String ghiChu;

    // Thông tin join (không lưu DB, dùng cho hiển thị)
    private transient CaLamTheoNgay caNgay;
    private transient String        tenNhanVien;

    // ── Trạng thái hợp lệ (constants) ─────────────────────────────────────

    public static final String TT_LAM_VIEC         = "Làm việc";
    public static final String TT_NGHI_PHEP         = "Nghỉ phép";
    public static final String TT_NGHI_KHONG_PHEP   = "Nghỉ không phép";
    public static final String TT_DI_TRE            = "Đi trễ";
    public static final String TT_TANG_CUONG        = "Tăng cường";
    public static final String TT_OT                = "OT";
    public static final String TT_DOI_CA            = "Đổi ca";

    // ── Constructors ──────────────────────────────────────────────────────

    public LichLamViec() {}

    public LichLamViec(int idLich, int idCaNgay,
                       String maNhanVien, String trangThai, String ghiChu) {
        this.idLich      = idLich;
        this.idCaNgay    = idCaNgay;
        this.maNhanVien  = maNhanVien;
        this.trangThai   = trangThai;
        this.ghiChu      = ghiChu;
    }

    // ── Getters & Setters ─────────────────────────────────────────────────

    public int    getIdLich()                   { return idLich; }
    public void   setIdLich(int v)              { this.idLich = v; }

    public int    getIdCaNgay()                 { return idCaNgay; }
    public void   setIdCaNgay(int v)            { this.idCaNgay = v; }

    public String getMaNhanVien()               { return maNhanVien; }
    public void   setMaNhanVien(String v)       { this.maNhanVien = v; }

    public String getTrangThai()                { return trangThai; }
    public void   setTrangThai(String v)        { this.trangThai = v; }

    public String getGhiChu()                   { return ghiChu; }
    public void   setGhiChu(String v)           { this.ghiChu = v; }

    public CaLamTheoNgay getCaNgay()            { return caNgay; }
    public void setCaNgay(CaLamTheoNgay v)      { this.caNgay = v; }

    public String getTenNhanVien()              { return tenNhanVien; }
    public void   setTenNhanVien(String v)      { this.tenNhanVien = v; }

    @Override
    public String toString() {
        return "LichLamViec[id=" + idLich
                + " | caNgay=" + idCaNgay
                + " | nv=" + maNhanVien
                + " | " + trangThai + "]";
    }
}
