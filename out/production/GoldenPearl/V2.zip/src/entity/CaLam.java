package entity;

import java.sql.Time;

/**
 * Entity ca làm CỐ ĐỊNH của nhà hàng.
 *
 * <p>Chỉ có 3 ca được tạo sẵn trong DB (seed SQL):
 * <ul>
 *   <li>C1 – Ca sáng</li>
 *   <li>C2 – Ca chiều</li>
 *   <li>C3 – Ca tối</li>
 * </ul>
 *
 * <p><b>Lưu ý thiết kế:</b> CaLam là dữ liệu mẫu/danh mục.
 * KHÔNG chứa trạng thái vận hành (đang mở / đang phục vụ / ...).
 * Trạng thái theo ngày được quản lý tại {@link CaLamTheoNgay}.
 */
public class CaLam {

    private String maCa;        // VD: C1, C2, C3
    private String tenCa;       // VD: Ca sáng, Ca chiều, Ca tối
    private Time   gioBatDau;
    private Time   gioKetThuc;

    public CaLam() {}

    public CaLam(String maCa, String tenCa, Time gioBatDau, Time gioKetThuc) {
        this.maCa       = maCa;
        this.tenCa      = tenCa;
        this.gioBatDau  = gioBatDau;
        this.gioKetThuc = gioKetThuc;
    }

    // ── Getters & Setters ──────────────────────────────────────────────────

    public String getMaCa()               { return maCa; }
    public void   setMaCa(String maCa)    { this.maCa = maCa; }

    public String getTenCa()              { return tenCa; }
    public void   setTenCa(String tenCa)  { this.tenCa = tenCa; }

    public Time getGioBatDau()                    { return gioBatDau; }
    public void setGioBatDau(Time gioBatDau)      { this.gioBatDau = gioBatDau; }

    public Time getGioKetThuc()                   { return gioKetThuc; }
    public void setGioKetThuc(Time gioKetThuc)    { this.gioKetThuc = gioKetThuc; }

    // ── Helpers ────────────────────────────────────────────────────────────

    /** Chuỗi rút gọn hiển thị trên UI: "Ca sáng (06:00 – 14:00)" */
    public String getDisplayName() {
        String bd = fmtTime(gioBatDau);
        String kt = fmtTime(gioKetThuc);
        return tenCa + " (" + bd + " – " + kt + ")";
    }

    private String fmtTime(Time t) {
        return t != null ? t.toString().substring(0, 5) : "--:--";
    }

    @Override
    public String toString() {
        return getDisplayName();
    }
}
