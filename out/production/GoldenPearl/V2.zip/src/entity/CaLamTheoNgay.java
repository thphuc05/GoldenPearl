package entity;

import java.sql.Date;

/**
 * Entity ca làm THỰC TẾ theo từng ngày.
 *
 * <p>Được generate tự động từ {@link DangKyCa} đã được duyệt.
 * Lưu trạng thái vận hành của từng ca theo từng ngày.
 *
 * <p><b>Tại sao tách riêng khỏi CaLam?</b><br>
 * {@link CaLam} chỉ là danh mục ca cố định (mẫu).
 * Trạng thái vận hành (đang mở / đang phục vụ / ...) là dữ liệu
 * vận hành thực tế, thay đổi theo từng ngày → phải tách riêng.
 *
 * <p><b>Trạng thái hợp lệ:</b>
 * <ul>
 *   <li>Chưa bắt đầu</li>
 *   <li>Đang mở</li>
 *   <li>Đang phục vụ</li>
 *   <li>Đã kết thúc</li>
 *   <li>Đã đóng</li>
 * </ul>
 *
 * <p>Unique constraint DB: (ngayLam, maCa) – mỗi ngày chỉ có 1 record / ca.
 */
public class CaLamTheoNgay {

    /** PK tự tăng */
    private int    idCaNgay;

    private Date   ngayLam;
    private String maCa;
    private String trangThai;

    // Thông tin join từ CaLam (không lưu DB, dùng cho hiển thị)
    private transient CaLam caLam;

    // ── Trạng thái hợp lệ (constants) ─────────────────────────────────────

    public static final String TT_CHUA_BAT_DAU  = "Chưa bắt đầu";
    public static final String TT_DANG_MO        = "Đang mở";
    public static final String TT_DANG_PHUC_VU   = "Đang phục vụ";
    public static final String TT_DA_KET_THUC    = "Đã kết thúc";
    public static final String TT_DA_DONG        = "Đã đóng";

    // ── Constructors ───────────────────────────────────────────────────────

    public CaLamTheoNgay() {}

    public CaLamTheoNgay(int idCaNgay, Date ngayLam, String maCa, String trangThai) {
        this.idCaNgay  = idCaNgay;
        this.ngayLam   = ngayLam;
        this.maCa      = maCa;
        this.trangThai = trangThai;
    }

    // ── Getters & Setters ─────────────────────────────────────────────────

    public int    getIdCaNgay()                 { return idCaNgay; }
    public void   setIdCaNgay(int v)            { this.idCaNgay = v; }

    public Date   getNgayLam()                  { return ngayLam; }
    public void   setNgayLam(Date v)            { this.ngayLam = v; }

    public String getMaCa()                     { return maCa; }
    public void   setMaCa(String v)             { this.maCa = v; }

    public String getTrangThai()                { return trangThai; }
    public void   setTrangThai(String v)        { this.trangThai = v; }

    public CaLam  getCaLam()                    { return caLam; }
    public void   setCaLam(CaLam v)             { this.caLam = v; }

    // ── Helpers ───────────────────────────────────────────────────────────

    /** Tên ca hiển thị (lấy từ caLam nếu đã join, fallback về maCa). */
    public String getTenCaDisplay() {
        return (caLam != null) ? caLam.getTenCa() : maCa;
    }

    /** Giờ bắt đầu dạng chuỗi "HH:mm". */
    public String getGioBatDauDisplay() {
        if (caLam == null || caLam.getGioBatDau() == null) return "--:--";
        return caLam.getGioBatDau().toString().substring(0, 5);
    }

    /** Giờ kết thúc dạng chuỗi "HH:mm". */
    public String getGioKetThucDisplay() {
        if (caLam == null || caLam.getGioKetThuc() == null) return "--:--";
        return caLam.getGioKetThuc().toString().substring(0, 5);
    }

    @Override
    public String toString() {
        return "CaLamTheoNgay[id=" + idCaNgay
                + " | ngay=" + ngayLam
                + " | ca=" + maCa
                + " | " + trangThai + "]";
    }
}
