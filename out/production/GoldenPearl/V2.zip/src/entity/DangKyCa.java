package entity;

import java.sql.Date;

/**
 * Entity đăng ký ca làm theo khoảng thời gian.
 *
 * <p>Nhân viên không được phân công trực tiếp từng ngày.
 * Thay vào đó, nhân viên đăng ký ca theo khoảng:
 * <pre>
 *   VD: NV01 đăng ký Ca sáng từ 01/06 đến 30/06, các thứ 2–6.
 * </pre>
 *
 * <p>Sau khi quản lý duyệt, hệ thống sẽ generate {@link CaLamTheoNgay}
 * và {@link LichLamViec} tự động.
 *
 * <p><b>maDangKy</b> – mã nghiệp vụ, KHÔNG phải primary key.
 * Format: {@code DK-<maCa>-<maNhanVien>-<ngayBatDau yyyyMMdd>}
 * VD: {@code DK-C1-NV01-20260601}
 *
 * <p><b>danhSachThu</b> – danh sách thứ trong tuần, phân cách bằng dấu phẩy.
 * VD: {@code "2,3,4,5,6"} (thứ 2 → thứ 6).
 * Nếu {@code NULL} → làm tất cả các ngày trong khoảng.
 */
public class DangKyCa {

    /** PK tự tăng – chỉ dùng nội bộ DB */
    private int    idDangKy;

    /** Mã nghiệp vụ hiển thị: DK-C1-NV01-20260601 */
    private String maDangKy;

    private String maNhanVien;
    private String maCa;
    private Date   ngayBatDau;
    private Date   ngayKetThuc;

    /**
     * Danh sách thứ cách nhau bằng dấu phẩy: "2,3,4,5,6".
     * NULL = làm tất cả các ngày.
     */
    private String danhSachThu;

    /**
     * Trạng thái: Chờ duyệt / Đã duyệt / Từ chối / Đã hủy
     */
    private String trangThai;

    // ── Constructors ──────────────────────────────────────────────────────

    public DangKyCa() {}

    public DangKyCa(int idDangKy, String maDangKy,
                    String maNhanVien, String maCa,
                    Date ngayBatDau, Date ngayKetThuc,
                    String danhSachThu, String trangThai) {
        this.idDangKy    = idDangKy;
        this.maDangKy    = maDangKy;
        this.maNhanVien  = maNhanVien;
        this.maCa        = maCa;
        this.ngayBatDau  = ngayBatDau;
        this.ngayKetThuc = ngayKetThuc;
        this.danhSachThu = danhSachThu;
        this.trangThai   = trangThai;
    }

    // ── Getters & Setters ─────────────────────────────────────────────────

    public int    getIdDangKy()                 { return idDangKy; }
    public void   setIdDangKy(int idDangKy)     { this.idDangKy = idDangKy; }

    public String getMaDangKy()                 { return maDangKy; }
    public void   setMaDangKy(String v)         { this.maDangKy = v; }

    public String getMaNhanVien()               { return maNhanVien; }
    public void   setMaNhanVien(String v)       { this.maNhanVien = v; }

    public String getMaCa()                     { return maCa; }
    public void   setMaCa(String v)             { this.maCa = v; }

    public Date   getNgayBatDau()               { return ngayBatDau; }
    public void   setNgayBatDau(Date v)         { this.ngayBatDau = v; }

    public Date   getNgayKetThuc()              { return ngayKetThuc; }
    public void   setNgayKetThuc(Date v)        { this.ngayKetThuc = v; }

    public String getDanhSachThu()              { return danhSachThu; }
    public void   setDanhSachThu(String v)      { this.danhSachThu = v; }

    public String getTrangThai()                { return trangThai; }
    public void   setTrangThai(String v)        { this.trangThai = v; }

    // ── Helpers ───────────────────────────────────────────────────────────

    /**
     * Sinh maDangKy theo quy tắc nghiệp vụ.
     * Format: DK-{maCa}-{maNhanVien}-{yyyyMMdd ngayBatDau}
     */
    public static String buildMaDangKy(String maCa, String maNhanVien, Date ngayBatDau) {
        String dateStr = new java.text.SimpleDateFormat("yyyyMMdd").format(ngayBatDau);
        return "DK-" + maCa + "-" + maNhanVien + "-" + dateStr;
    }

    /**
     * Kiểm tra một ngày cụ thể có nằm trong lịch đăng ký không.
     * Xét cả khoảng ngày và danhSachThu.
     */
    public boolean includesDate(java.util.Date ngay) {
        if (ngayBatDau == null || ngayKetThuc == null || ngay == null) return false;
        if (ngay.before(ngayBatDau) || ngay.after(ngayKetThuc)) return false;
        if (danhSachThu == null || danhSachThu.trim().isEmpty()) return true;

        java.util.Calendar c = java.util.Calendar.getInstance();
        c.setTime(ngay);
        int dow = c.get(java.util.Calendar.DAY_OF_WEEK);
        // Java: Sunday=1, Monday=2, ..., Saturday=7 → khớp với "2,3,4,5,6,7,1"
        for (String part : danhSachThu.split(",")) {
            if (part.trim().equals(String.valueOf(dow))) return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return "DangKyCa[" + maDangKy + " | " + maNhanVien + " | " + maCa
                + " | " + ngayBatDau + " → " + ngayKetThuc
                + " | thu: " + danhSachThu + " | " + trangThai + "]";
    }
}
